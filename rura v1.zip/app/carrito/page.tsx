"use client"

import { useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { ShoppingCart, Plus, Minus, Trash2, MessageCircle, ArrowLeft, Package } from "lucide-react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { useCart, useCartActions } from "@/lib/cart-context"

export default function CartPage() {
  const { state: cartState } = useCart()
  const { updateQuantity, removeFromCart, clearCart } = useCartActions()
  const [notes, setNotes] = useState("")

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("es-CO", {
      style: "currency",
      currency: "COP",
      minimumFractionDigits: 0,
    }).format(price)
  }

  const handleQuantityChange = (productId: number, newQuantity: number) => {
    if (newQuantity <= 0) {
      removeFromCart(productId)
    } else {
      updateQuantity(productId, newQuantity)
    }
  }

  const handleWhatsAppCheckout = () => {
    if (cartState.items.length === 0) return

    // Group items by producer
    const itemsByProducer = cartState.items.reduce(
      (acc, item) => {
        const producerId = item.producer.id
        if (!acc[producerId]) {
          acc[producerId] = {
            producer: item.producer,
            items: [],
            total: 0,
          }
        }
        acc[producerId].items.push(item)
        acc[producerId].total += item.price * item.quantity
        return acc
      },
      {} as Record<number, { producer: any; items: any[]; total: number }>,
    )

    // Send separate messages to each producer
    Object.values(itemsByProducer).forEach(({ producer, items, total }) => {
      const itemsList = items
        .map(
          (item) =>
            `• ${item.name} - Cantidad: ${item.quantity} ${item.unit}(s) - ${formatPrice(item.price * item.quantity)}`,
        )
        .join("\n")

      const message = `Hola ${producer.name}, me gustaría hacer un pedido desde Rura:

${itemsList}

Total: ${formatPrice(total)}

${notes ? `Notas adicionales: ${notes}` : ""}

¿Podrías confirmar la disponibilidad y coordinar la entrega?

¡Gracias!`

      const whatsappUrl = `https://wa.me/${producer.phone.replace("+", "")}?text=${encodeURIComponent(message)}`
      window.open(whatsappUrl, "_blank")
    })

    // Clear cart after sending messages
    setTimeout(() => {
      clearCart()
    }, 1000)
  }

  if (cartState.items.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-16">
          <div className="text-center max-w-md mx-auto">
            <div className="h-24 w-24 rounded-full bg-secondary flex items-center justify-center mx-auto mb-6">
              <ShoppingCart className="h-12 w-12 text-muted-foreground" />
            </div>
            <h1 className="font-serif text-2xl font-bold mb-4">Tu carrito está vacío</h1>
            <p className="text-muted-foreground mb-6">Descubre productos frescos de nuestros productores locales</p>
            <Button size="lg" asChild>
              <Link href="/productos">
                <Package className="h-5 w-5 mr-2" />
                Explorar Productos
              </Link>
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <Button variant="ghost" className="mb-4" asChild>
              <Link href="/productos">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Continuar Comprando
              </Link>
            </Button>
            <h1 className="font-serif text-3xl font-bold">Mi Carrito</h1>
            <p className="text-muted-foreground">
              {cartState.itemCount} {cartState.itemCount === 1 ? "producto" : "productos"} en tu carrito
            </p>
          </div>
          <Button variant="outline" onClick={clearCart} className="bg-transparent">
            <Trash2 className="h-4 w-4 mr-2" />
            Vaciar Carrito
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cartState.items.map((item) => (
              <Card key={item.id}>
                <CardContent className="p-6">
                  <div className="flex space-x-4">
                    <img
                      src={item.image || "/placeholder.svg"}
                      alt={item.name}
                      className="w-20 h-20 object-cover rounded-lg"
                    />
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          <Link href={`/productos/${item.id}`}>
                            <h3 className="font-semibold hover:text-primary transition-colors cursor-pointer">
                              {item.name}
                            </h3>
                          </Link>
                          <Badge variant="outline" className="text-xs mt-1">
                            {item.category}
                          </Badge>
                          <div className="flex items-center space-x-2 mt-2 text-sm text-muted-foreground">
                            <span>Por {item.producer.name}</span>
                            <span>•</span>
                            <span>{item.producer.location}</span>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeFromCart(item.id)}
                          className="text-muted-foreground hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="flex items-center justify-between mt-4">
                        <div className="flex items-center space-x-3">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 bg-transparent"
                            onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                          >
                            <Minus className="h-4 w-4" />
                          </Button>
                          <span className="w-12 text-center font-medium">
                            {item.quantity} {item.unit}
                            {item.quantity > 1 ? "s" : ""}
                          </span>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8 bg-transparent"
                            onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold">{formatPrice(item.price * item.quantity)}</div>
                          <div className="text-sm text-muted-foreground">
                            {formatPrice(item.price)} / {item.unit}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Order Summary */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="font-serif">Resumen del Pedido</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {cartState.items.map((item) => (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span>
                        {item.name} x{item.quantity}
                      </span>
                      <span>{formatPrice(item.price * item.quantity)}</span>
                    </div>
                  ))}
                </div>
                <Separator />
                <div className="flex justify-between font-semibold text-lg">
                  <span>Total</span>
                  <span className="text-primary">{formatPrice(cartState.total)}</span>
                </div>
              </CardContent>
            </Card>

            {/* Notes */}
            <Card>
              <CardHeader>
                <CardTitle className="font-serif text-lg">Notas del Pedido</CardTitle>
              </CardHeader>
              <CardContent>
                <Label htmlFor="notes" className="text-sm text-muted-foreground">
                  Instrucciones especiales, preferencias de entrega, etc.
                </Label>
                <Textarea
                  id="notes"
                  placeholder="Ej: Prefiero entrega en la mañana, productos bien maduros..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="mt-2"
                  rows={3}
                />
              </CardContent>
            </Card>

            {/* Checkout */}
            <Card>
              <CardContent className="p-6">
                <Button size="lg" className="w-full text-lg py-6" onClick={handleWhatsAppCheckout}>
                  <MessageCircle className="h-5 w-5 mr-2" />
                  Contactar Productores
                </Button>
                <p className="text-xs text-muted-foreground text-center mt-3">
                  Se abrirá WhatsApp para contactar directamente con cada productor
                </p>
              </CardContent>
            </Card>

            {/* Info */}
            <div className="bg-secondary/20 rounded-lg p-4">
              <h4 className="font-semibold mb-2">¿Cómo funciona?</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Contactas directamente con cada productor</li>
                <li>• Coordinas entrega y pago</li>
                <li>• Recibes productos frescos</li>
                <li>• Sin intermediarios, precios justos</li>
              </ul>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
