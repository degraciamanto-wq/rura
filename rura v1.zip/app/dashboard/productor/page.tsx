"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Package, MessageCircle, Plus, Edit, Eye, Phone, MapPin, Star } from "lucide-react"
import Link from "next/link"

export default function ProducerDashboard() {
  const [producerData, setProducerData] = useState<any>(null)

  useEffect(() => {
    // Cargar datos del productor desde localStorage
    const data = localStorage.getItem("producerData")
    if (data) {
      setProducerData(JSON.parse(data))
    }
  }, [])

  if (!producerData) {
    return (
      <div className="min-h-screen bg-secondary/10 flex items-center justify-center">
        <div className="text-center">
          <h2 className="font-serif text-2xl font-bold mb-4">Cargando dashboard...</h2>
          <p className="text-muted-foreground">
            <Link href="/login/productor" className="text-primary hover:underline">
              Iniciar sesión como productor
            </Link>
          </p>
        </div>
      </div>
    )
  }

  const stats = [
    {
      title: "Productos Activos",
      value: "12",
      description: "+2 este mes",
      icon: Package,
      color: "text-primary",
    },
    {
      title: "Consultas WhatsApp",
      value: "48",
      description: "+15 esta semana",
      icon: MessageCircle,
      color: "text-green-600",
    },
    {
      title: "Vistas de Perfil",
      value: "234",
      description: "+23% vs mes anterior",
      icon: Eye,
      color: "text-blue-600",
    },
    {
      title: "Calificación",
      value: "4.8",
      description: "Basado en 24 reseñas",
      icon: Star,
      color: "text-yellow-600",
    },
  ]

  const recentProducts = [
    {
      id: 1,
      name: "Tomates Cherry Orgánicos",
      category: "Frutas",
      price: 8000,
      unit: "kg",
      status: "Activo",
      views: 45,
      inquiries: 8,
    },
    {
      id: 2,
      name: "Lechuga Crespa",
      category: "Verduras",
      price: 3500,
      unit: "unidad",
      status: "Activo",
      views: 32,
      inquiries: 5,
    },
    {
      id: 3,
      name: "Aguacate Hass",
      category: "Frutas",
      price: 4200,
      unit: "unidad",
      status: "Agotado",
      views: 67,
      inquiries: 12,
    },
  ]

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("es-CO", {
      style: "currency",
      currency: "COP",
      minimumFractionDigits: 0,
    }).format(price)
  }

  return (
    <div className="min-h-screen bg-secondary/10">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="font-serif text-3xl font-bold">Bienvenido, {producerData.firstName}</h1>
              <p className="text-muted-foreground mt-1">Panel de control de {producerData.farmName}</p>
            </div>
            <div className="flex items-center space-x-4">
              <Button asChild>
                <Link href="/dashboard/productor/productos/nuevo">
                  <Plus className="h-4 w-4 mr-2" />
                  Nuevo Producto
                </Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/">Ver Marketplace</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Resumen</TabsTrigger>
            <TabsTrigger value="products">Productos</TabsTrigger>
            <TabsTrigger value="profile">Perfil</TabsTrigger>
            <TabsTrigger value="messages">Mensajes</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {stats.map((stat, index) => {
                const IconComponent = stat.icon
                return (
                  <Card key={index}>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                      <IconComponent className={`h-4 w-4 ${stat.color}`} />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{stat.value}</div>
                      <p className="text-xs text-muted-foreground">{stat.description}</p>
                    </CardContent>
                  </Card>
                )
              })}
            </div>

            {/* Recent Products */}
            <Card>
              <CardHeader>
                <CardTitle className="font-serif">Productos Recientes</CardTitle>
                <CardDescription>Tus productos más recientes y su rendimiento</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentProducts.map((product) => (
                    <div key={product.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <h4 className="font-semibold">{product.name}</h4>
                        <div className="flex items-center space-x-4 mt-1 text-sm text-muted-foreground">
                          <span>{product.category}</span>
                          <span>•</span>
                          <span>
                            {formatPrice(product.price)} / {product.unit}
                          </span>
                          <Badge variant={product.status === "Activo" ? "default" : "secondary"}>
                            {product.status}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex items-center space-x-6 text-sm">
                        <div className="text-center">
                          <div className="font-semibold">{product.views}</div>
                          <div className="text-muted-foreground">Vistas</div>
                        </div>
                        <div className="text-center">
                          <div className="font-semibold">{product.inquiries}</div>
                          <div className="text-muted-foreground">Consultas</div>
                        </div>
                        <Button variant="ghost" size="icon">
                          <Edit className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="products">
            <Card>
              <CardHeader>
                <CardTitle className="font-serif">Gestión de Productos</CardTitle>
                <CardDescription>Administra tu catálogo de productos</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-serif text-lg font-semibold mb-2">Gestión de Productos</h3>
                  <p className="text-muted-foreground mb-4">
                    Aquí podrás agregar, editar y gestionar todos tus productos
                  </p>
                  <Button asChild>
                    <Link href="/dashboard/productor/productos/nuevo">
                      <Plus className="h-4 w-4 mr-2" />
                      Agregar Primer Producto
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <CardTitle className="font-serif">Perfil del Productor</CardTitle>
                <CardDescription>Información que ven los consumidores</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-semibold mb-3">Información Personal</h3>
                    <div className="space-y-2 text-sm">
                      <div>
                        <strong>Nombre:</strong> {producerData.firstName} {producerData.lastName}
                      </div>
                      <div>
                        <strong>Email:</strong> {producerData.email}
                      </div>
                      <div className="flex items-center">
                        <Phone className="h-4 w-4 mr-2" />
                        <strong>Teléfono:</strong> {producerData.phone}
                      </div>
                      <div className="flex items-center">
                        <MessageCircle className="h-4 w-4 mr-2" />
                        <strong>WhatsApp:</strong> {producerData.whatsapp}
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-3">Información de la Finca</h3>
                    <div className="space-y-2 text-sm">
                      <div>
                        <strong>Finca:</strong> {producerData.farmName}
                      </div>
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-2" />
                        <strong>Ubicación:</strong> {producerData.city}, {producerData.department}
                      </div>
                      <div>
                        <strong>Tamaño:</strong> {producerData.farmSize} hectáreas
                      </div>
                      <div>
                        <strong>Especialidades:</strong> {producerData.specialties}
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold mb-3">Descripción</h3>
                  <p className="text-sm text-muted-foreground bg-muted p-4 rounded-lg">{producerData.description}</p>
                </div>

                <Button>
                  <Edit className="h-4 w-4 mr-2" />
                  Editar Perfil
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="messages">
            <Card>
              <CardHeader>
                <CardTitle className="font-serif">Centro de Mensajes</CardTitle>
                <CardDescription>Consultas y mensajes de WhatsApp</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <MessageCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="font-serif text-lg font-semibold mb-2">Centro de Mensajes</h3>
                  <p className="text-muted-foreground mb-4">Aquí aparecerán las consultas que recibas vía WhatsApp</p>
                  <p className="text-sm text-muted-foreground">
                    Los consumidores pueden contactarte directamente desde tus productos
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
