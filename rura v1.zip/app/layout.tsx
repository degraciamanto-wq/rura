import type React from "react"
import type { Metadata } from "next"
import { Analytics } from "@vercel/analytics/next"
import { Suspense } from "react"
import { CartProvider } from "@/lib/cart-context"
import { SearchProvider } from "@/lib/search-context"
import "./globals.css"

export const metadata: Metadata = {
  title: "Rura - Marketplace Agrícola",
  description: "Conectamos productores y consumidores de productos agrícolas frescos",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es">
      <body className="font-sans antialiased">
        <SearchProvider>
          <CartProvider>
            <Suspense fallback={<div>Loading...</div>}>{children}</Suspense>
          </CartProvider>
        </SearchProvider>
        <Analytics />
      </body>
    </html>
  )
}
