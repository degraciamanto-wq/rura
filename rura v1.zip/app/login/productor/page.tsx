"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Sprout, Eye, EyeOff } from "lucide-react"
import { useRouter } from "next/navigation"

export default function ProducerLoginPage() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulación de login
    setTimeout(() => {
      setIsLoading(false)
      // Aquí iría la lógica real de autenticación
      localStorage.setItem("userType", "productor")
      localStorage.setItem("userEmail", email)
      router.push("/dashboard/productor")
    }, 1500)
  }

  return (
    <div className="min-h-screen bg-secondary/10 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center space-x-2 mb-6">
            <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-serif font-bold text-xl">R</span>
            </div>
            <span className="font-serif text-3xl font-bold rura-text-gradient">Rura</span>
          </Link>
        </div>

        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 h-12 w-12 rounded-full bg-secondary flex items-center justify-center">
              <Sprout className="h-6 w-6 text-accent" />
            </div>
            <CardTitle className="font-serif text-2xl">Portal del Productor</CardTitle>
            <CardDescription>Accede a tu panel de control para gestionar tus productos</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Correo Electrónico</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="tu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Contraseña</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Tu contraseña"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Iniciando sesión..." : "Acceder al Panel"}
              </Button>
            </form>

            <div className="mt-6 text-center space-y-4">
              <Link href="/recuperar-password" className="text-sm text-primary hover:underline">
                ¿Olvidaste tu contraseña?
              </Link>

              <div className="border-t pt-4">
                <p className="text-sm text-muted-foreground mb-2">¿No tienes cuenta de productor?</p>
                <Button variant="outline" className="w-full bg-transparent" asChild>
                  <Link href="/registro/productor">Registrarse como Productor</Link>
                </Button>
              </div>

              <div className="border-t pt-4">
                <p className="text-sm text-muted-foreground mb-2">¿Eres consumidor?</p>
                <Button variant="ghost" className="w-full" asChild>
                  <Link href="/login/consumidor">Iniciar Sesión como Consumidor</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
