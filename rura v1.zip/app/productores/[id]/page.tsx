"use client"

import { useParams } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Star, MapPin, MessageCircle, Phone, ArrowLeft, Award, Calendar, Sprout } from "lucide-react"
import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { WhatsAppContact, WhatsAppFloatingButton } from "@/components/whatsapp-contact"
import { ContactProducerModal } from "@/components/contact-producer-modal"

// Mock data - en una app real vendría de una API
const getProducerById = (id: string) => {
  const producers = [
    {
      id: 1,
      name: "María González",
      farmName: "Finca Los Cerezos",
      location: "Cundinamarca",
      rating: 4.8,
      reviewCount: 24,
      phone: "+573001234567",
      whatsapp: "+573001234567",
      email: "maria@fincaloscerezo.com",
      experience: "15 años",
      farmSize: "12 hectáreas",
      specialties: ["Semillas orgánicas", "Hortalizas", "Cultivos sostenibles"],
      certifications: ["Orgánico certificado", "Comercio justo", "Agricultura sostenible"],
      description:
        "Soy María González, agricultora de tercera generación con más de 15 años de experiencia en cultivos orgánicos. Mi finca 'Los Cerezos' se especializa en la producción de semillas certificadas y hortalizas frescas, utilizando métodos de agricultura sostenible que respetan el medio ambiente y garantizan productos de la más alta calidad.",
      story:
        "Mi pasión por la agricultura comenzó desde pequeña, ayudando a mis abuelos en su huerta familiar. Después de estudiar ingeniería agronómica, decidí dedicarme completamente a la agricultura orgánica, convirtiendo nuestra finca familiar en un referente de sostenibilidad en la región.",
      products: [
        {
          id: 1,
          name: "Semillas de Tomate Cherry Orgánico",
          category: "Semillas",
          price: 15000,
          unit: "paquete",
          image: "/semillas-tomate-cherry-organico.jpg",
          inStock: true,
        },
        {
          id: 3,
          name: "Semillas de Cilantro Orgánico",
          category: "Semillas",
          price: 6000,
          unit: "paquete",
          image: "/semillas-cilantro-organico.jpg",
          inStock: true,
        },
      ],
      images: [
        "/finca-los-cerezos-cultivos.jpg",
        "/maria-gonzalez-agricultora.jpg",
        "/invernadero-organico-tomates.jpg",
      ],
    },
  ]

  return producers.find((p) => p.id === Number.parseInt(id)) || null
}

export default function ProducerProfilePage() {
  const params = useParams()
  const producer = getProducerById(params.id as string)

  if (!producer) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="font-serif text-2xl font-bold mb-4">Productor no encontrado</h1>
          <Button asChild>
            <Link href="/productores">Volver a productores</Link>
          </Button>
        </div>
        <Footer />
      </div>
    )
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("es-CO", {
      style: "currency",
      currency: "COP",
      minimumFractionDigits: 0,
    }).format(price)
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center space-x-2 text-sm text-muted-foreground mb-6">
          <Link href="/" className="hover:text-primary">
            Inicio
          </Link>
          <span>/</span>
          <Link href="/productores" className="hover:text-primary">
            Productores
          </Link>
          <span>/</span>
          <span className="text-foreground">{producer.name}</span>
        </div>

        {/* Back Button */}
        <Button variant="ghost" className="mb-6" asChild>
          <Link href="/productores">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Volver a productores
          </Link>
        </Button>

        {/* Producer Header */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          <div className="lg:col-span-2">
            <div className="flex items-start space-x-6">
              <div className="h-24 w-24 rounded-full bg-secondary flex items-center justify-center text-3xl font-serif font-bold text-accent">
                {producer.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </div>
              <div className="flex-1">
                <h1 className="font-serif text-3xl font-bold mb-2">{producer.name}</h1>
                <h2 className="text-xl text-muted-foreground mb-3">{producer.farmName}</h2>

                <div className="flex items-center space-x-4 mb-4">
                  <div className="flex items-center space-x-1">
                    <Star className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                    <span className="font-semibold">{producer.rating}</span>
                    <span className="text-muted-foreground">({producer.reviewCount} reseñas)</span>
                  </div>
                  <div className="flex items-center space-x-1 text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    <span>{producer.location}</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 mb-4">
                  {producer.specialties.map((specialty, index) => (
                    <Badge key={index} variant="secondary">
                      {specialty}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <WhatsAppContact phone={producer.whatsapp} producerName={producer.name} size="lg" className="w-full" />
            <ContactProducerModal
              producer={{
                id: producer.id.toString(),
                name: producer.name,
                phone: producer.whatsapp,
                email: producer.email,
                location: producer.location,
                farm: producer.farmName,
                specialties: producer.specialties,
              }}
            >
              <Button variant="outline" size="lg" className="w-full bg-transparent">
                <MessageCircle className="h-5 w-5 mr-2" />
                Contacto Avanzado
              </Button>
            </ContactProducerModal>
          </div>
        </div>

        {/* Producer Images */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
          {producer.images.map((image, index) => (
            <div key={index} className="aspect-video overflow-hidden rounded-lg">
              <img
                src={image || "/placeholder.svg"}
                alt={`${producer.farmName} ${index + 1}`}
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* About */}
            <Card>
              <CardContent className="p-6">
                <h3 className="font-serif text-2xl font-semibold mb-4">Sobre {producer.name}</h3>
                <p className="text-muted-foreground leading-relaxed mb-6">{producer.description}</p>
                <h4 className="font-semibold mb-3">Mi Historia</h4>
                <p className="text-muted-foreground leading-relaxed">{producer.story}</p>
              </CardContent>
            </Card>

            {/* Products */}
            <Card>
              <CardContent className="p-6">
                <h3 className="font-serif text-2xl font-semibold mb-6">Productos de {producer.name}</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {producer.products.map((product) => (
                    <div key={product.id} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex space-x-4">
                        <img
                          src={product.image || "/placeholder.svg"}
                          alt={product.name}
                          className="w-20 h-20 object-cover rounded-lg"
                        />
                        <div className="flex-1">
                          <Link href={`/productos/${product.id}`}>
                            <h4 className="font-semibold hover:text-primary transition-colors cursor-pointer">
                              {product.name}
                            </h4>
                          </Link>
                          <Badge variant="outline" className="text-xs mt-1">
                            {product.category}
                          </Badge>
                          <div className="mt-2">
                            <span className="font-bold text-primary">{formatPrice(product.price)}</span>
                            <span className="text-muted-foreground text-sm ml-1">/ {product.unit}</span>
                          </div>
                          {product.inStock && (
                            <Badge className="bg-green-500 text-white text-xs mt-1">Disponible</Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="text-center mt-6">
                  <Button variant="outline" asChild>
                    <Link href={`/productos?productor=${producer.id}`}>Ver todos los productos</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Farm Info */}
            <Card>
              <CardContent className="p-6">
                <h3 className="font-serif text-xl font-semibold mb-4">Información de la Finca</h3>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <Sprout className="h-5 w-5 text-primary" />
                    <div>
                      <div className="font-medium">Tamaño</div>
                      <div className="text-sm text-muted-foreground">{producer.farmSize}</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Calendar className="h-5 w-5 text-primary" />
                    <div>
                      <div className="font-medium">Experiencia</div>
                      <div className="text-sm text-muted-foreground">{producer.experience}</div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <MapPin className="h-5 w-5 text-primary" />
                    <div>
                      <div className="font-medium">Ubicación</div>
                      <div className="text-sm text-muted-foreground">{producer.location}</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Certifications */}
            <Card>
              <CardContent className="p-6">
                <h3 className="font-serif text-xl font-semibold mb-4">Certificaciones</h3>
                <div className="space-y-3">
                  {producer.certifications.map((cert, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <Award className="h-5 w-5 text-primary" />
                      <span className="text-sm">{cert}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Contact Info */}
            <Card>
              <CardContent className="p-6">
                <h3 className="font-serif text-xl font-semibold mb-4">Contacto</h3>
                <div className="space-y-3">
                  <WhatsAppContact
                    phone={producer.whatsapp}
                    producerName={producer.name}
                    variant="outline"
                    className="w-full justify-start bg-transparent"
                    showIcon={true}
                  />
                  <Button variant="outline" className="w-full justify-start bg-transparent">
                    <Phone className="h-4 w-4 mr-2" />
                    Teléfono: {producer.phone}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <WhatsAppFloatingButton phone={producer.whatsapp} producerName={producer.name} />

      <Footer />
    </div>
  )
}
