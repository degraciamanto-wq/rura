"use client"

import { useState } from "react"
import { useParams } from "next/navigation"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Star, MapPin, MessageCircle, ArrowLeft, Heart, Share2, Package, Truck, Shield } from "lucide-react"
import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { AddToCartButton } from "@/components/add-to-cart-button"
import { WhatsAppContact, WhatsAppFloatingButton } from "@/components/whatsapp-contact"
import { ContactProducerModal } from "@/components/contact-producer-modal"

// Mock data - en una app real vendría de una API
const getProductById = (id: string) => {
  const products = [
    {
      id: 1,
      name: "Semillas de Tomate Cherry Orgánico",
      category: "Semillas",
      price: 15000,
      unit: "paquete",
      images: [
        "/semillas-tomate-cherry-organico.jpg",
        "/semillas-tomate-cherry-detalle.jpg",
        "/tomate-cherry-planta-creciendo.jpg",
      ],
      producer: {
        id: 1,
        name: "María González",
        location: "Cundinamarca",
        rating: 4.8,
        reviewCount: 24,
        phone: "+573001234567",
        whatsapp: "+573001234567",
        farmName: "Finca Los Cerezos",
        experience: "15 años",
        specialties: ["Semillas orgánicas", "Hortalizas", "Cultivos sostenibles"],
      },
      description:
        "Semillas certificadas orgánicas de tomate cherry, perfectas para huertos caseros. Estas semillas han sido seleccionadas cuidadosamente para garantizar una alta tasa de germinación y plantas resistentes.",
      features: [
        "Certificación orgánica",
        "Alta tasa de germinación (95%)",
        "Resistente a plagas comunes",
        "Ideal para cultivo en macetas",
        "Tiempo de cosecha: 60-70 días",
      ],
      specifications: {
        Variedad: "Cherry orgánico",
        Origen: "Cundinamarca, Colombia",
        Certificación: "Orgánico certificado",
        Germinación: "95%",
        "Tiempo de cosecha": "60-70 días",
        Contenido: "50 semillas por paquete",
      },
      inStock: true,
      stockQuantity: 25,
      featured: true,
    },
  ]

  return products.find((p) => p.id === Number.parseInt(id)) || null
}

export default function ProductDetailPage() {
  const params = useParams()
  const product = getProductById(params.id as string)
  const [selectedImage, setSelectedImage] = useState(0)

  if (!product) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="font-serif text-2xl font-bold mb-4">Producto no encontrado</h1>
          <Button asChild>
            <Link href="/productos">Volver al catálogo</Link>
          </Button>
        </div>
        <Footer />
      </div>
    )
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("es-CO", {
      style: "currency",
      currency: "COP",
      minimumFractionDigits: 0,
    }).format(price)
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product.name,
        text: product.description,
        url: window.location.href,
      })
    } else {
      navigator.clipboard.writeText(window.location.href)
      alert("Enlace copiado al portapapeles")
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="flex items-center space-x-2 text-sm text-muted-foreground mb-6">
          <Link href="/" className="hover:text-primary">
            Inicio
          </Link>
          <span>/</span>
          <Link href="/productos" className="hover:text-primary">
            Productos
          </Link>
          <span>/</span>
          <Link href={`/categoria/${product.category.toLowerCase()}`} className="hover:text-primary">
            {product.category}
          </Link>
          <span>/</span>
          <span className="text-foreground">{product.name}</span>
        </div>

        {/* Back Button */}
        <Button variant="ghost" className="mb-6" asChild>
          <Link href="/productos">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Volver al catálogo
          </Link>
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="aspect-square overflow-hidden rounded-lg border">
              <img
                src={product.images[selectedImage] || "/placeholder.svg"}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`aspect-square overflow-hidden rounded-lg border-2 transition-colors ${
                    selectedImage === index ? "border-primary" : "border-border hover:border-primary/50"
                  }`}
                >
                  <img
                    src={image || "/placeholder.svg"}
                    alt={`${product.name} ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <div className="flex items-center justify-between mb-2">
                <Badge className="bg-primary text-primary-foreground">{product.category}</Badge>
                <div className="flex items-center space-x-2">
                  <Button variant="ghost" size="icon" onClick={handleShare}>
                    <Share2 className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon">
                    <Heart className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <h1 className="font-serif text-3xl font-bold mb-4">{product.name}</h1>
              <p className="text-muted-foreground text-lg">{product.description}</p>
            </div>

            {/* Price */}
            <div className="bg-secondary/20 rounded-lg p-6">
              <div className="flex items-baseline space-x-2 mb-4">
                <span className="text-4xl font-bold text-primary">{formatPrice(product.price)}</span>
                <span className="text-muted-foreground text-lg">/ {product.unit}</span>
              </div>

              {/* Stock Status */}
              <div className="flex items-center space-x-2 mb-6">
                <Package className="h-4 w-4 text-green-600" />
                <span className="text-sm text-green-600 font-medium">
                  En stock ({product.stockQuantity} disponibles)
                </span>
              </div>

              {/* Add to Cart */}
              <div className="space-y-4">
                <AddToCartButton
                  product={{
                    id: product.id,
                    name: product.name,
                    price: product.price,
                    unit: product.unit,
                    image: product.images[0],
                    category: product.category,
                    producer: product.producer,
                  }}
                  size="lg"
                  className="w-full text-lg py-6"
                  showQuantitySelector={true}
                />

                {/* WhatsApp Contact Button */}
                <WhatsAppContact
                  phone={product.producer.whatsapp}
                  productName={product.name}
                  producerName={product.producer.name}
                  variant="outline"
                  size="lg"
                  className="w-full text-lg py-6 bg-transparent"
                />
              </div>
            </div>

            {/* Producer Info */}
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-serif text-xl font-semibold">Productor</h3>
                  <div className="flex gap-2">
                    <Link href={`/productores/${product.producer.id}`}>
                      <Button variant="outline" size="sm">
                        Ver perfil
                      </Button>
                    </Link>
                    <ContactProducerModal
                      producer={{
                        id: product.producer.id.toString(),
                        name: product.producer.name,
                        phone: product.producer.whatsapp,
                        email: "maria@fincaloscerezo.com",
                        location: product.producer.location,
                        farm: product.producer.farmName,
                        specialties: product.producer.specialties,
                      }}
                      productName={product.name}
                    >
                      <Button size="sm">
                        <MessageCircle className="w-4 h-4 mr-2" />
                        Contactar
                      </Button>
                    </ContactProducerModal>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{product.producer.name}</span>
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="font-medium">{product.producer.rating}</span>
                      <span className="text-muted-foreground text-sm">({product.producer.reviewCount} reseñas)</span>
                    </div>
                  </div>

                  <div className="flex items-center text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span>{product.producer.location}</span>
                  </div>

                  <div className="text-sm">
                    <span className="font-medium">Finca:</span> {product.producer.farmName}
                  </div>

                  <div className="text-sm">
                    <span className="font-medium">Experiencia:</span> {product.producer.experience}
                  </div>

                  <div className="flex flex-wrap gap-2 mt-3">
                    {product.producer.specialties.map((specialty, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {specialty}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Product Details Tabs */}
        <div className="mt-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Features */}
            <Card>
              <CardContent className="p-6">
                <h3 className="font-serif text-xl font-semibold mb-4">Características</h3>
                <ul className="space-y-2">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-center space-x-2">
                      <div className="h-2 w-2 rounded-full bg-primary"></div>
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Specifications */}
            <Card>
              <CardContent className="p-6">
                <h3 className="font-serif text-xl font-semibold mb-4">Especificaciones</h3>
                <div className="space-y-3">
                  {Object.entries(product.specifications).map(([key, value]) => (
                    <div key={key} className="flex justify-between">
                      <span className="font-medium">{key}:</span>
                      <span className="text-muted-foreground">{value}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex items-center space-x-3 p-4 bg-secondary/20 rounded-lg">
            <Shield className="h-8 w-8 text-primary" />
            <div>
              <h4 className="font-semibold">Producto Verificado</h4>
              <p className="text-sm text-muted-foreground">Productor certificado</p>
            </div>
          </div>

          <div className="flex items-center space-x-3 p-4 bg-secondary/20 rounded-lg">
            <Truck className="h-8 w-8 text-primary" />
            <div>
              <h4 className="font-semibold">Entrega Coordinada</h4>
              <p className="text-sm text-muted-foreground">Contacto directo con productor</p>
            </div>
          </div>

          <div className="flex items-center space-x-3 p-4 bg-secondary/20 rounded-lg">
            <MessageCircle className="h-8 w-8 text-primary" />
            <div>
              <h4 className="font-semibold">Soporte WhatsApp</h4>
              <p className="text-sm text-muted-foreground">Comunicación directa</p>
            </div>
          </div>
        </div>
      </main>

      <WhatsAppFloatingButton phone={product.producer.whatsapp} producerName={product.producer.name} />

      <Footer />
    </div>
  )
}
