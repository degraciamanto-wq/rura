"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Star, MapPin, MessageCircle, Search, Filter, SlidersHorizontal } from "lucide-react"
import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { AddToCartButton } from "@/components/add-to-cart-button"
import { AdvancedFilters } from "@/components/advanced-filters"
import { useSearch } from "@/lib/search-context"

const allProducts = [
  // Semillas
  {
    id: 1,
    name: "Semillas de Tomate Cherry Orgánico",
    category: "Semillas",
    price: 15000,
    unit: "paquete",
    image: "/semillas-tomate-cherry-organico.jpg",
    producer: {
      id: 1,
      name: "María González",
      location: "Cundinamarca",
      rating: 4.8,
      phone: "+573001234567",
    },
    description: "Semillas certificadas orgánicas de tomate cherry, perfectas para huertos caseros.",
    inStock: true,
    featured: true,
  },
  {
    id: 2,
    name: "Semillas de Lechuga Crespa",
    category: "Semillas",
    price: 8000,
    unit: "paquete",
    image: "/semillas-lechuga-crespa-verde.jpg",
    producer: {
      id: 2,
      name: "Carlos Rodríguez",
      location: "Boyacá",
      rating: 4.9,
      phone: "+573007654321",
    },
    description: "Semillas de lechuga crespa de rápido crecimiento y excelente sabor.",
    inStock: true,
    featured: false,
  },
  {
    id: 3,
    name: "Semillas de Cilantro Orgánico",
    category: "Semillas",
    price: 6000,
    unit: "paquete",
    image: "/semillas-cilantro-organico.jpg",
    producer: {
      id: 1,
      name: "María González",
      location: "Cundinamarca",
      rating: 4.8,
      phone: "+573001234567",
    },
    description: "Semillas de cilantro orgánico, aromático y de crecimiento rápido.",
    inStock: true,
    featured: false,
  },
  // Granos
  {
    id: 4,
    name: "Quinoa Blanca Premium",
    category: "Granos",
    price: 25000,
    unit: "kg",
    image: "/quinoa-blanca-premium-granos.jpg",
    producer: {
      id: 3,
      name: "Ana Martínez",
      location: "Nariño",
      rating: 4.7,
      phone: "+573009876543",
    },
    description: "Quinoa blanca de alta calidad, rica en proteínas y libre de pesticidas.",
    inStock: true,
    featured: true,
  },
  {
    id: 5,
    name: "Frijol Rojo Orgánico",
    category: "Granos",
    price: 18000,
    unit: "kg",
    image: "/frijoles-rojos-organicos.jpg",
    producer: {
      id: 4,
      name: "Pedro Sánchez",
      location: "Huila",
      rating: 4.6,
      phone: "+573005432109",
    },
    description: "Frijoles rojos cultivados orgánicamente, perfectos para preparaciones tradicionales.",
    inStock: true,
    featured: false,
  },
  {
    id: 6,
    name: "Arroz Integral Orgánico",
    category: "Granos",
    price: 12000,
    unit: "kg",
    image: "/arroz-integral-organico-granos.jpg",
    producer: {
      id: 5,
      name: "Roberto Jiménez",
      location: "Tolima",
      rating: 4.5,
      phone: "+573008765432",
    },
    description: "Arroz integral cultivado sin químicos, rico en fibra y nutrientes.",
    inStock: true,
    featured: false,
  },
  // Frutas
  {
    id: 7,
    name: "Aguacate Hass",
    category: "Frutas",
    price: 3500,
    unit: "unidad",
    image: "/aguacate-hass-maduro.jpg",
    producer: {
      id: 6,
      name: "Luis Herrera",
      location: "Antioquia",
      rating: 4.9,
      phone: "+573002468135",
    },
    description: "Aguacates Hass en punto perfecto de maduración, cremosos y nutritivos.",
    inStock: true,
    featured: true,
  },
  {
    id: 8,
    name: "Mango Tommy",
    category: "Frutas",
    price: 2800,
    unit: "unidad",
    image: "/mango-tommy-maduro-dulce.jpg",
    producer: {
      id: 7,
      name: "Carmen López",
      location: "Magdalena",
      rating: 4.8,
      phone: "+573001357924",
    },
    description: "Mangos Tommy dulces y jugosos, perfectos para consumo directo o jugos.",
    inStock: true,
    featured: false,
  },
  {
    id: 9,
    name: "Banano Orgánico",
    category: "Frutas",
    price: 4500,
    unit: "kg",
    image: "/banano-organico-maduro.jpg",
    producer: {
      id: 8,
      name: "Diego Morales",
      location: "Quindío",
      rating: 4.7,
      phone: "+573003691258",
    },
    description: "Bananos orgánicos maduros, dulces y nutritivos, cultivados sin pesticidas.",
    inStock: false,
    featured: false,
  },
]

export default function ProductsPage() {
  const { searchState, setSearchTerm, setCategory, setSortBy } = useSearch()
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false)
  const [localSearchTerm, setLocalSearchTerm] = useState("")

  // Sincronizar término de búsqueda local con el global
  useEffect(() => {
    setLocalSearchTerm(searchState.searchTerm)
  }, [searchState.searchTerm])

  const categories = ["all", "Semillas", "Granos", "Frutas"]

  const filteredProducts = allProducts
    .filter((product) => {
      const matchesSearch =
        product.name.toLowerCase().includes(searchState.searchTerm.toLowerCase()) ||
        product.producer.name.toLowerCase().includes(searchState.searchTerm.toLowerCase()) ||
        product.description.toLowerCase().includes(searchState.searchTerm.toLowerCase())

      const matchesCategory = searchState.category === "all" || product.category === searchState.category

      const matchesLocation = searchState.location === "all" || product.producer.location === searchState.location

      const matchesPrice = product.price >= searchState.priceRange[0] && product.price <= searchState.priceRange[1]

      const matchesStock = !searchState.onlyInStock || product.inStock

      return matchesSearch && matchesCategory && matchesLocation && matchesPrice && matchesStock
    })
    .sort((a, b) => {
      switch (searchState.sortBy) {
        case "price-low":
          return a.price - b.price
        case "price-high":
          return b.price - a.price
        case "rating":
          return b.producer.rating - a.producer.rating
        case "name":
          return a.name.localeCompare(b.name)
        case "newest":
          return b.id - a.id
        case "featured":
        default:
          return b.featured ? 1 : -1
      }
    })

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("es-CO", {
      style: "currency",
      currency: "COP",
      minimumFractionDigits: 0,
    }).format(price)
  }

  const handleWhatsAppContact = (phone: string, productName: string, producerName: string) => {
    const message = `Hola ${producerName}, estoy interesado en tu producto: ${productName}. ¿Podrías darme más información?`
    const whatsappUrl = `https://wa.me/${phone.replace("+", "")}?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
  }

  const handleLocalSearch = (value: string) => {
    setLocalSearchTerm(value)
    setSearchTerm(value)
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto px-4 py-8">
        {/* Page Header */}
        <div className="text-center mb-8">
          <h1 className="font-serif text-4xl font-bold mb-4">Catálogo de Productos</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Descubre productos frescos directamente de nuestros productores locales
          </p>
        </div>

        {/* Filters */}
        <div className="bg-card rounded-lg p-6 mb-8 border">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Buscar productos..."
                value={localSearchTerm}
                onChange={(e) => handleLocalSearch(e.target.value)}
                className="pl-10"
              />
            </div>

            {/* Category Filter */}
            <Select value={searchState.category} onValueChange={setCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Categoría" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las categorías</SelectItem>
                {categories.slice(1).map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Sort */}
            <Select value={searchState.sortBy} onValueChange={setSortBy}>
              <SelectTrigger>
                <SelectValue placeholder="Ordenar por" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="featured">Destacados</SelectItem>
                <SelectItem value="price-low">Precio: Menor a Mayor</SelectItem>
                <SelectItem value="price-high">Precio: Mayor a Menor</SelectItem>
                <SelectItem value="rating">Mejor Calificación</SelectItem>
                <SelectItem value="name">Nombre A-Z</SelectItem>
                <SelectItem value="newest">Más Recientes</SelectItem>
              </SelectContent>
            </Select>

            {/* Advanced Filters Button */}
            <Button variant="outline" onClick={() => setShowAdvancedFilters(true)} className="bg-transparent">
              <SlidersHorizontal className="h-4 w-4 mr-2" />
              Filtros Avanzados
            </Button>

            {/* Results Count */}
            <div className="flex items-center justify-center md:justify-start">
              <span className="text-sm text-muted-foreground">{filteredProducts.length} productos encontrados</span>
            </div>
          </div>

          {/* Active Filters Display */}
          {(searchState.category !== "all" || searchState.location !== "all" || searchState.searchTerm) && (
            <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t">
              <span className="text-sm font-medium text-muted-foreground">Filtros activos:</span>
              {searchState.searchTerm && (
                <Badge variant="secondary" className="flex items-center space-x-1">
                  <span>Búsqueda: "{searchState.searchTerm}"</span>
                  <button onClick={() => setSearchTerm("")} className="ml-1 hover:text-destructive">
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              )}
              {searchState.category !== "all" && (
                <Badge variant="secondary" className="flex items-center space-x-1">
                  <span>Categoría: {searchState.category}</span>
                  <button onClick={() => setCategory("all")} className="ml-1 hover:text-destructive">
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              )}
              {searchState.location !== "all" && (
                <Badge variant="secondary" className="flex items-center space-x-1">
                  <span>Ubicación: {searchState.location}</span>
                  <button onClick={() => setLocation("all")} className="ml-1 hover:text-destructive">
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              )}
            </div>
          )}
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <Card key={product.id} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
              <CardContent className="p-0">
                <div className="relative overflow-hidden rounded-t-lg">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <Badge className="absolute top-3 left-3 bg-primary text-primary-foreground">{product.category}</Badge>
                  {product.featured && (
                    <Badge className="absolute top-3 right-3 bg-yellow-500 text-white">Destacado</Badge>
                  )}
                  {product.inStock ? (
                    <Badge className="absolute bottom-3 right-3 bg-green-500 text-white">Disponible</Badge>
                  ) : (
                    <Badge className="absolute bottom-3 right-3 bg-red-500 text-white">Agotado</Badge>
                  )}
                </div>

                <div className="p-6">
                  <Link href={`/productos/${product.id}`}>
                    <h3 className="font-serif text-xl font-semibold mb-2 group-hover:text-primary transition-colors cursor-pointer">
                      {product.name}
                    </h3>
                  </Link>

                  <p className="text-muted-foreground text-sm mb-3 line-clamp-2">{product.description}</p>

                  {/* Producer Info */}
                  <div className="flex items-center justify-between mb-4 text-sm">
                    <Link
                      href={`/productores/${product.producer.id}`}
                      className="flex items-center space-x-2 hover:text-primary transition-colors"
                    >
                      <div className="flex items-center space-x-1">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="font-medium">{product.producer.rating}</span>
                      </div>
                      <span className="text-muted-foreground">•</span>
                      <span className="font-medium">{product.producer.name}</span>
                    </Link>
                  </div>

                  <div className="flex items-center text-sm text-muted-foreground mb-4">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span>{product.producer.location}</span>
                  </div>

                  {/* Price */}
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <span className="text-2xl font-bold text-primary">{formatPrice(product.price)}</span>
                      <span className="text-muted-foreground ml-1">/ {product.unit}</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex space-x-2">
                    {product.inStock ? (
                      <AddToCartButton
                        product={{
                          id: product.id,
                          name: product.name,
                          price: product.price,
                          unit: product.unit,
                          image: product.image,
                          category: product.category,
                          producer: product.producer,
                        }}
                        className="flex-1"
                        size="sm"
                      />
                    ) : (
                      <Button disabled className="flex-1" size="sm">
                        Agotado
                      </Button>
                    )}
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-transparent"
                      onClick={() => handleWhatsAppContact(product.producer.phone, product.name, product.producer.name)}
                    >
                      <MessageCircle className="h-4 w-4 mr-1" />
                      WhatsApp
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* No Results */}
        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <div className="h-24 w-24 rounded-full bg-secondary flex items-center justify-center mx-auto mb-4">
              <Filter className="h-12 w-12 text-muted-foreground" />
            </div>
            <h3 className="font-serif text-xl font-semibold mb-2">No se encontraron productos</h3>
            <p className="text-muted-foreground mb-4">Intenta ajustar tus filtros o términos de búsqueda</p>
            <Button
              variant="outline"
              onClick={() => {
                setSearchTerm("")
                setCategory("all")
                setSortBy("featured")
              }}
            >
              Limpiar Filtros
            </Button>
          </div>
        )}
      </main>

      <Footer />

      {/* Advanced Filters Modal */}
      <AdvancedFilters isOpen={showAdvancedFilters} onClose={() => setShowAdvancedFilters(false)} />
    </div>
  )
}
