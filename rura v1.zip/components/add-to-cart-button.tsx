"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Plus, Minus } from "lucide-react"
import { useCartActions, type CartItem } from "@/lib/cart-context"
import { useToast } from "@/hooks/use-toast"

interface AddToCartButtonProps {
  product: Omit<CartItem, "quantity">
  className?: string
  variant?: "default" | "outline" | "ghost"
  size?: "default" | "sm" | "lg"
  showQuantitySelector?: boolean
}

export function AddToCartButton({
  product,
  className,
  variant = "default",
  size = "default",
  showQuantitySelector = false,
}: AddToCartButtonProps) {
  const [quantity, setQuantity] = useState(1)
  const [isAdding, setIsAdding] = useState(false)
  const { addToCart } = useCartActions()
  const { toast } = useToast()

  const handleAddToCart = async () => {
    setIsAdding(true)

    try {
      addToCart(product, quantity)

      toast({
        title: "Producto agregado",
        description: `${product.name} se agregó al carrito`,
      })

      // Reset quantity after adding
      if (showQuantitySelector) {
        setQuantity(1)
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo agregar el producto al carrito",
        variant: "destructive",
      })
    } finally {
      setIsAdding(false)
    }
  }

  if (showQuantitySelector) {
    return (
      <div className="flex items-center space-x-2">
        <div className="flex items-center space-x-2 border rounded-lg">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => setQuantity(Math.max(1, quantity - 1))}
            disabled={quantity <= 1}
          >
            <Minus className="h-4 w-4" />
          </Button>
          <span className="w-8 text-center text-sm font-medium">{quantity}</span>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setQuantity(quantity + 1)}>
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        <Button variant={variant} size={size} className={className} onClick={handleAddToCart} disabled={isAdding}>
          <ShoppingCart className="h-4 w-4 mr-2" />
          {isAdding ? "Agregando..." : "Agregar"}
        </Button>
      </div>
    )
  }

  return (
    <Button variant={variant} size={size} className={className} onClick={handleAddToCart} disabled={isAdding}>
      <ShoppingCart className="h-4 w-4 mr-2" />
      {isAdding ? "Agregando..." : "Agregar al Carrito"}
    </Button>
  )
}
