"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Filter, X, MapPin, DollarSign, Package, Star } from "lucide-react"
import { useSearch } from "@/lib/search-context"

const categories = ["Semillas", "Granos", "Frutas", "Verduras", "Hierbas"]
const locations = [
  "Antioquia",
  "Boyacá",
  "Cundinamarca",
  "Huila",
  "Magdalena",
  "Nariño",
  "Quindío",
  "Tolima",
  "Valle del Cauca",
]

interface AdvancedFiltersProps {
  isOpen: boolean
  onClose: () => void
}

export function AdvancedFilters({ isOpen, onClose }: AdvancedFiltersProps) {
  const { searchState, setCategory, setLocation, setPriceRange, setSortBy, setOnlyInStock, clearFilters } = useSearch()

  const [tempPriceRange, setTempPriceRange] = useState(searchState.priceRange)

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("es-CO", {
      style: "currency",
      currency: "COP",
      minimumFractionDigits: 0,
    }).format(price)
  }

  const handlePriceRangeChange = (value: number[]) => {
    setTempPriceRange([value[0], value[1]])
    setPriceRange([value[0], value[1]])
  }

  const getActiveFiltersCount = () => {
    let count = 0
    if (searchState.category !== "all") count++
    if (searchState.location !== "all") count++
    if (searchState.priceRange[0] > 0 || searchState.priceRange[1] < 100000) count++
    if (!searchState.onlyInStock) count++
    return count
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center space-x-2">
            <Filter className="h-5 w-5" />
            <CardTitle>Filtros Avanzados</CardTitle>
            {getActiveFiltersCount() > 0 && <Badge variant="secondary">{getActiveFiltersCount()} activos</Badge>}
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Category Filter */}
          <div className="space-y-3">
            <Label className="flex items-center space-x-2">
              <Package className="h-4 w-4" />
              <span>Categoría</span>
            </Label>
            <Select value={searchState.category} onValueChange={setCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona una categoría" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las categorías</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Location Filter */}
          <div className="space-y-3">
            <Label className="flex items-center space-x-2">
              <MapPin className="h-4 w-4" />
              <span>Ubicación</span>
            </Label>
            <Select value={searchState.location} onValueChange={setLocation}>
              <SelectTrigger>
                <SelectValue placeholder="Selecciona una ubicación" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las ubicaciones</SelectItem>
                {locations.map((location) => (
                  <SelectItem key={location} value={location}>
                    {location}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Price Range */}
          <div className="space-y-3">
            <Label className="flex items-center space-x-2">
              <DollarSign className="h-4 w-4" />
              <span>Rango de Precio</span>
            </Label>
            <div className="px-3">
              <Slider
                value={tempPriceRange}
                onValueChange={handlePriceRangeChange}
                max={100000}
                min={0}
                step={1000}
                className="w-full"
              />
              <div className="flex justify-between text-sm text-muted-foreground mt-2">
                <span>{formatPrice(tempPriceRange[0])}</span>
                <span>{formatPrice(tempPriceRange[1])}</span>
              </div>
            </div>
          </div>

          {/* Sort By */}
          <div className="space-y-3">
            <Label className="flex items-center space-x-2">
              <Star className="h-4 w-4" />
              <span>Ordenar por</span>
            </Label>
            <Select value={searchState.sortBy} onValueChange={setSortBy}>
              <SelectTrigger>
                <SelectValue placeholder="Ordenar por" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="featured">Destacados</SelectItem>
                <SelectItem value="price-low">Precio: Menor a Mayor</SelectItem>
                <SelectItem value="price-high">Precio: Mayor a Menor</SelectItem>
                <SelectItem value="rating">Mejor Calificación</SelectItem>
                <SelectItem value="name">Nombre A-Z</SelectItem>
                <SelectItem value="newest">Más Recientes</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Stock Filter */}
          <div className="flex items-center space-x-2">
            <Checkbox
              id="inStock"
              checked={searchState.onlyInStock}
              onCheckedChange={(checked) => setOnlyInStock(checked as boolean)}
            />
            <Label htmlFor="inStock">Solo productos en stock</Label>
          </div>

          {/* Actions */}
          <div className="flex space-x-3 pt-4">
            <Button variant="outline" onClick={clearFilters} className="flex-1 bg-transparent">
              Limpiar Filtros
            </Button>
            <Button onClick={onClose} className="flex-1">
              Aplicar Filtros
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
