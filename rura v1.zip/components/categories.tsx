import { Card, CardContent } from "@/components/ui/card"
import { Wheat, Apple, Sprout } from "lucide-react"
import Link from "next/link"

const categories = [
  {
    id: "semillas",
    name: "Semillas",
    description: "Semillas de alta calidad para tu huerto",
    icon: Sprout,
    image: "/semillas-organicas-variadas.jpg",
    count: "25+ productos",
  },
  {
    id: "granos",
    name: "Granos",
    description: "Granos frescos y nutritivos",
    icon: Wheat,
    image: "/granos-cereales-quinoa-arroz.jpg",
    count: "40+ productos",
  },
  {
    id: "frutas",
    name: "Frutas",
    description: "Frutas frescas de temporada",
    icon: Apple,
    image: "/frutas-frescas-organicas-coloridas.jpg",
    count: "60+ productos",
  },
]

export function Categories() {
  return (
    <section className="py-16 bg-secondary/20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">Nuestras Categorías</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Descubre la variedad de productos frescos que nuestros productores tienen para ti
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {categories.map((category) => {
            const IconComponent = category.icon
            return (
              <Link key={category.id} href={`/categoria/${category.id}`}>
                <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer">
                  <CardContent className="p-0">
                    <div className="relative overflow-hidden rounded-t-lg">
                      <img
                        src={category.image || "/placeholder.svg"}
                        alt={category.name}
                        className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors duration-300"></div>
                      <div className="absolute top-4 left-4">
                        <div className="h-12 w-12 rounded-full bg-white/90 flex items-center justify-center">
                          <IconComponent className="h-6 w-6 text-accent" />
                        </div>
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className="font-serif text-2xl font-semibold mb-2 group-hover:text-primary transition-colors">
                        {category.name}
                      </h3>
                      <p className="text-muted-foreground mb-3">{category.description}</p>
                      <p className="text-sm font-medium text-primary">{category.count}</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            )
          })}
        </div>
      </div>
    </section>
  )
}
