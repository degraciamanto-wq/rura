"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { MessageCircle, Phone, Mail, MapPin } from "lucide-react"
import { WhatsAppContact } from "./whatsapp-contact"

interface Producer {
  id: string
  name: string
  phone: string
  email?: string
  location: string
  farm: string
  specialties: string[]
}

interface ContactProducerModalProps {
  producer: Producer
  productName?: string
  children: React.ReactNode
}

export function ContactProducerModal({ producer, productName, children }: ContactProducerModalProps) {
  const [customMessage, setCustomMessage] = useState("")
  const [contactMethod, setContactMethod] = useState<"whatsapp" | "email">("whatsapp")

  const handleEmailContact = () => {
    const subject = `Consulta sobre productos - Rura Marketplace`
    let body = `Hola ${producer.name},\n\nEstoy interesado en tus productos en Rura Marketplace.`

    if (productName) {
      body += `\n\nEspecíficamente me interesa: ${productName}.`
    }

    if (customMessage) {
      body += `\n\nMensaje adicional: ${customMessage}`
    }

    body += `\n\n¿Podrías darme más información sobre disponibilidad y precios?\n\nGracias,`

    const mailtoUrl = `mailto:${producer.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
    window.open(mailtoUrl, "_blank")
  }

  return (
    <Dialog>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-league-gothic text-xl">Contactar a {producer.name}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Producer Info */}
          <div className="bg-verde-pastel/20 p-4 rounded-lg">
            <h3 className="font-semibold text-verde-bosque">{producer.farm}</h3>
            <div className="flex items-center gap-2 text-sm text-gray-600 mt-1">
              <MapPin className="w-4 h-4" />
              {producer.location}
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-600 mt-1">
              <Phone className="w-4 h-4" />
              {producer.phone}
            </div>
            {producer.email && (
              <div className="flex items-center gap-2 text-sm text-gray-600 mt-1">
                <Mail className="w-4 h-4" />
                {producer.email}
              </div>
            )}
          </div>

          {/* Product Info */}
          {productName && (
            <div className="bg-caqui-claro/20 p-3 rounded-lg">
              <p className="text-sm">
                <span className="font-semibold">Producto de interés:</span> {productName}
              </p>
            </div>
          )}

          {/* Contact Method Selection */}
          <div className="space-y-3">
            <Label>Método de contacto preferido:</Label>
            <div className="flex gap-2">
              <Button
                variant={contactMethod === "whatsapp" ? "default" : "outline"}
                size="sm"
                onClick={() => setContactMethod("whatsapp")}
                className={contactMethod === "whatsapp" ? "bg-green-600 hover:bg-green-700" : ""}
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                WhatsApp
              </Button>
              {producer.email && (
                <Button
                  variant={contactMethod === "email" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setContactMethod("email")}
                >
                  <Mail className="w-4 h-4 mr-2" />
                  Email
                </Button>
              )}
            </div>
          </div>

          {/* Custom Message */}
          <div className="space-y-2">
            <Label htmlFor="message">Mensaje personalizado (opcional):</Label>
            <Textarea
              id="message"
              placeholder="Agrega cualquier información adicional o pregunta específica..."
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              rows={3}
            />
          </div>

          {/* Contact Actions */}
          <div className="flex gap-2 pt-4">
            {contactMethod === "whatsapp" ? (
              <WhatsAppContact
                phone={producer.phone}
                message={customMessage || undefined}
                productName={productName}
                producerName={producer.name}
                className="flex-1"
              />
            ) : (
              <Button onClick={handleEmailContact} className="flex-1 bg-blue-600 hover:bg-blue-700">
                <Mail className="w-4 h-4 mr-2" />
                Enviar Email
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
