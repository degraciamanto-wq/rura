"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Star, MapPin, MessageCircle } from "lucide-react"
import { AddToCartButton } from "@/components/add-to-cart-button"

const featuredProducts = [
  // Semillas
  {
    id: 1,
    name: "Semillas de Tomate Cherry Orgánico",
    category: "Semillas",
    price: 15000,
    unit: "paquete",
    image: "/semillas-tomate-cherry-organico.jpg",
    producer: {
      id: 1,
      name: "María González",
      location: "Cundinamarca",
      rating: 4.8,
      phone: "+573001234567",
    },
    description: "Semillas certificadas orgánicas de tomate cherry, perfectas para huertos caseros.",
    inStock: true,
  },
  {
    id: 2,
    name: "Semillas de Lechuga Crespa",
    category: "Semillas",
    price: 8000,
    unit: "paquete",
    image: "/semillas-lechuga-crespa-verde.jpg",
    producer: {
      id: 2,
      name: "Carlos Rodríguez",
      location: "Boyacá",
      rating: 4.9,
      phone: "+573007654321",
    },
    description: "Semillas de lechuga crespa de rápido crecimiento y excelente sabor.",
    inStock: true,
  },
  // Granos
  {
    id: 3,
    name: "Quinoa Blanca Premium",
    category: "Granos",
    price: 25000,
    unit: "kg",
    image: "/quinoa-blanca-premium-granos.jpg",
    producer: {
      id: 3,
      name: "Ana Martínez",
      location: "Nariño",
      rating: 4.7,
      phone: "+573009876543",
    },
    description: "Quinoa blanca de alta calidad, rica en proteínas y libre de pesticidas.",
    inStock: true,
  },
  {
    id: 4,
    name: "Frijol Rojo Orgánico",
    category: "Granos",
    price: 18000,
    unit: "kg",
    image: "/frijoles-rojos-organicos.jpg",
    producer: {
      id: 4,
      name: "Pedro Sánchez",
      location: "Huila",
      rating: 4.6,
      phone: "+573005432109",
    },
    description: "Frijoles rojos cultivados orgánicamente, perfectos para preparaciones tradicionales.",
    inStock: true,
  },
  // Frutas
  {
    id: 5,
    name: "Aguacate Hass",
    category: "Frutas",
    price: 3500,
    unit: "unidad",
    image: "/aguacate-hass-maduro.jpg",
    producer: {
      id: 5,
      name: "Luis Herrera",
      location: "Antioquia",
      rating: 4.9,
      phone: "+573002468135",
    },
    description: "Aguacates Hass en punto perfecto de maduración, cremosos y nutritivos.",
    inStock: true,
  },
  {
    id: 6,
    name: "Mango Tommy",
    category: "Frutas",
    price: 2800,
    unit: "unidad",
    image: "/mango-tommy-maduro-dulce.jpg",
    producer: {
      id: 6,
      name: "Carmen López",
      location: "Magdalena",
      rating: 4.8,
      phone: "+573001357924",
    },
    description: "Mangos Tommy dulces y jugosos, perfectos para consumo directo o jugos.",
    inStock: true,
  },
]

export function FeaturedProducts() {
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("es-CO", {
      style: "currency",
      currency: "COP",
      minimumFractionDigits: 0,
    }).format(price)
  }

  const handleWhatsAppContact = (phone: string, productName: string, producerName: string) => {
    const message = `Hola ${producerName}, estoy interesado en tu producto: ${productName}. ¿Podrías darme más información?`
    const whatsappUrl = `https://wa.me/${phone.replace("+", "")}?text=${encodeURIComponent(message)}`
    window.open(whatsappUrl, "_blank")
  }

  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">Productos Destacados</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Los mejores productos de nuestros productores más confiables
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredProducts.map((product) => (
            <Card key={product.id} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
              <CardContent className="p-0">
                <div className="relative overflow-hidden rounded-t-lg">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <Badge className="absolute top-3 left-3 bg-primary text-primary-foreground">{product.category}</Badge>
                  {product.inStock && (
                    <Badge className="absolute top-3 right-3 bg-green-500 text-white">Disponible</Badge>
                  )}
                </div>

                <div className="p-6">
                  <h3 className="font-serif text-xl font-semibold mb-2 group-hover:text-primary transition-colors">
                    {product.name}
                  </h3>

                  <p className="text-muted-foreground text-sm mb-3 line-clamp-2">{product.description}</p>

                  {/* Producer Info */}
                  <div className="flex items-center justify-between mb-4 text-sm">
                    <div className="flex items-center space-x-2">
                      <div className="flex items-center space-x-1">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="font-medium">{product.producer.rating}</span>
                      </div>
                      <span className="text-muted-foreground">•</span>
                      <span className="font-medium">{product.producer.name}</span>
                    </div>
                  </div>

                  <div className="flex items-center text-sm text-muted-foreground mb-4">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span>{product.producer.location}</span>
                  </div>

                  {/* Price */}
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <span className="text-2xl font-bold text-primary">{formatPrice(product.price)}</span>
                      <span className="text-muted-foreground ml-1">/ {product.unit}</span>
                    </div>
                  </div>

                  {/* Actions - Agregando botón de carrito y manteniendo WhatsApp */}
                  <div className="flex space-x-2">
                    <AddToCartButton
                      product={{
                        id: product.id,
                        name: product.name,
                        price: product.price,
                        unit: product.unit,
                        image: product.image,
                        category: product.category,
                        producer: product.producer,
                      }}
                      className="flex-1"
                      size="sm"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-transparent"
                      onClick={() => handleWhatsAppContact(product.producer.phone, product.name, product.producer.name)}
                    >
                      <MessageCircle className="h-4 w-4 mr-1" />
                      WhatsApp
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button size="lg" variant="outline" asChild>
            <a href="/productos">Ver Todos los Productos</a>
          </Button>
        </div>
      </div>
    </section>
  )
}
