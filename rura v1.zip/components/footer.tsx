import Link from "next/link"
import { Leaf, Facebook, Instagram, Twitter } from "lucide-react"

export function Footer() {
  return (
    <footer className="bg-accent text-accent-foreground">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
                <Leaf className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="font-serif text-2xl font-bold text-white">Rura</span>
            </div>
            <p className="text-accent-foreground/80 mb-4 max-w-md">
              Conectamos productores agrícolas con consumidores conscientes. Productos frescos, directos del campo a tu
              mesa.
            </p>
            <div className="flex space-x-4">
              <Link href="#" className="text-accent-foreground/60 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-accent-foreground/60 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-accent-foreground/60 hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
              </Link>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-serif text-lg font-semibold mb-4 text-white">Enlaces Rápidos</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/productos" className="text-accent-foreground/80 hover:text-white transition-colors">
                  Productos
                </Link>
              </li>
              <li>
                <Link href="/productores" className="text-accent-foreground/80 hover:text-white transition-colors">
                  Productores
                </Link>
              </li>
              <li>
                <Link href="/como-funciona" className="text-accent-foreground/80 hover:text-white transition-colors">
                  Cómo Funciona
                </Link>
              </li>
              <li>
                <Link href="/contacto" className="text-accent-foreground/80 hover:text-white transition-colors">
                  Contacto
                </Link>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="font-serif text-lg font-semibold mb-4 text-white">Soporte</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/ayuda" className="text-accent-foreground/80 hover:text-white transition-colors">
                  Centro de Ayuda
                </Link>
              </li>
              <li>
                <Link href="/terminos" className="text-accent-foreground/80 hover:text-white transition-colors">
                  Términos y Condiciones
                </Link>
              </li>
              <li>
                <Link href="/privacidad" className="text-accent-foreground/80 hover:text-white transition-colors">
                  Política de Privacidad
                </Link>
              </li>
              <li>
                <Link
                  href="/registro/productor"
                  className="text-accent-foreground/80 hover:text-white transition-colors"
                >
                  Únete como Productor
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-accent-foreground/20 mt-8 pt-8 text-center">
          <p className="text-accent-foreground/60">
            © 2025 Rura. Todos los derechos reservados. Conectando el campo con tu mesa.
          </p>
        </div>
      </div>
    </footer>
  )
}
