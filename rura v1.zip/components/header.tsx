"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Search, ShoppingCart, User, Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useCart } from "@/lib/cart-context"
import { useSearch } from "@/lib/search-context"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [localSearchTerm, setLocalSearchTerm] = useState("")
  const { state: cartState } = useCart()
  const { setSearchTerm } = useSearch()
  const router = useRouter()

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (localSearchTerm.trim()) {
      setSearchTerm(localSearchTerm.trim())
      router.push("/productos")
    }
  }

  const handleSearchInputChange = (value: string) => {
    setLocalSearchTerm(value)
    // Búsqueda en tiempo real si estamos en la página de productos
    if (window.location.pathname === "/productos") {
      setSearchTerm(value)
    }
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-serif font-bold text-lg">R</span>
            </div>
            <span className="font-serif text-2xl font-bold rura-text-gradient">Rura</span>
          </Link>

          {/* Search Bar - Desktop - Agregando funcionalidad de búsqueda */}
          <div className="hidden md:flex flex-1 max-w-md mx-8">
            <form onSubmit={handleSearch} className="relative w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Buscar productos, productores..."
                className="pl-10 pr-4"
                value={localSearchTerm}
                onChange={(e) => handleSearchInputChange(e.target.value)}
              />
            </form>
          </div>

          {/* Navigation - Desktop */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/productos" className="text-foreground hover:text-primary transition-colors">
              Productos
            </Link>
            <Link href="/productores" className="text-foreground hover:text-primary transition-colors">
              Productores
            </Link>
            <Link href="/como-funciona" className="text-foreground hover:text-primary transition-colors">
              Cómo Funciona
            </Link>
          </nav>

          {/* Actions */}
          <div className="flex items-center space-x-4">
            {/* Cart */}
            <Button variant="ghost" size="icon" className="relative" asChild>
              <Link href="/carrito">
                <ShoppingCart className="h-5 w-5" />
                {cartState.itemCount > 0 && (
                  <span className="absolute -top-2 -right-2 h-5 w-5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                    {cartState.itemCount}
                  </span>
                )}
              </Link>
            </Button>

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <User className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <Link href="/login/consumidor">Iniciar Sesión - Consumidor</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/login/productor">Iniciar Sesión - Productor</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/registro">Registrarse</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Mobile Menu Button */}
            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <div className="flex flex-col space-y-4">
              {/* Mobile Search - Agregando funcionalidad de búsqueda móvil */}
              <form onSubmit={handleSearch} className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Buscar productos, productores..."
                  className="pl-10 pr-4"
                  value={localSearchTerm}
                  onChange={(e) => handleSearchInputChange(e.target.value)}
                />
              </form>

              {/* Mobile Navigation */}
              <nav className="flex flex-col space-y-2">
                <Link href="/productos" className="text-foreground hover:text-primary transition-colors py-2">
                  Productos
                </Link>
                <Link href="/productores" className="text-foreground hover:text-primary transition-colors py-2">
                  Productores
                </Link>
                <Link href="/como-funciona" className="text-foreground hover:text-primary transition-colors py-2">
                  Cómo Funciona
                </Link>
              </nav>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}
