"use client"

import { MessageCircle } from "lucide-react"
import { Button } from "@/components/ui/button"

interface WhatsAppContactProps {
  phone: string
  message?: string
  productName?: string
  producerName?: string
  className?: string
  variant?: "default" | "outline" | "ghost"
  size?: "sm" | "default" | "lg"
  showIcon?: boolean
}

export function WhatsAppContact({
  phone,
  message,
  productName,
  producerName,
  className = "",
  variant = "default",
  size = "default",
  showIcon = true,
}: WhatsAppContactProps) {
  const formatPhone = (phone: string) => {
    // Remove any non-numeric characters and ensure it starts with country code
    const cleaned = phone.replace(/\D/g, "")
    if (cleaned.startsWith("57")) return cleaned
    if (cleaned.startsWith("3")) return `57${cleaned}`
    return `57${cleaned}`
  }

  const generateMessage = () => {
    if (message) return message

    let defaultMessage = `Hola ${producerName || "productor"}, estoy interesado en tus productos en Rura Marketplace.`

    if (productName) {
      defaultMessage += ` Específicamente me interesa: ${productName}.`
    }

    defaultMessage += " ¿Podrías darme más información sobre disponibilidad y precios?"

    return defaultMessage
  }

  const handleWhatsAppClick = () => {
    const formattedPhone = formatPhone(phone)
    const encodedMessage = encodeURIComponent(generateMessage())
    const whatsappUrl = `https://wa.me/${formattedPhone}?text=${encodedMessage}`
    window.open(whatsappUrl, "_blank")
  }

  return (
    <Button
      onClick={handleWhatsAppClick}
      variant={variant}
      size={size}
      className={`bg-green-600 hover:bg-green-700 text-white ${className}`}
    >
      {showIcon && <MessageCircle className="w-4 h-4 mr-2" />}
      Contactar por WhatsApp
    </Button>
  )
}

export function WhatsAppFloatingButton({ phone, producerName }: { phone: string; producerName: string }) {
  return (
    <div className="fixed bottom-6 right-6 z-50">
      <WhatsAppContact
        phone={phone}
        producerName={producerName}
        className="rounded-full w-14 h-14 shadow-lg hover:shadow-xl transition-shadow"
        size="lg"
        showIcon={true}
      />
    </div>
  )
}
