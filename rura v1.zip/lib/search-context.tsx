"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

interface SearchState {
  searchTerm: string
  category: string
  location: string
  priceRange: [number, number]
  sortBy: string
  onlyInStock: boolean
}

interface SearchContextType {
  searchState: SearchState
  setSearchTerm: (term: string) => void
  setCategory: (category: string) => void
  setLocation: (location: string) => void
  setPriceRange: (range: [number, number]) => void
  setSortBy: (sortBy: string) => void
  setOnlyInStock: (inStock: boolean) => void
  clearFilters: () => void
}

const SearchContext = createContext<SearchContextType | null>(null)

const initialState: SearchState = {
  searchTerm: "",
  category: "all",
  location: "all",
  priceRange: [0, 100000],
  sortBy: "featured",
  onlyInStock: true,
}

export function SearchProvider({ children }: { children: ReactNode }) {
  const [searchState, setSearchState] = useState<SearchState>(initialState)

  const setSearchTerm = (term: string) => {
    setSearchState((prev) => ({ ...prev, searchTerm: term }))
  }

  const setCategory = (category: string) => {
    setSearchState((prev) => ({ ...prev, category }))
  }

  const setLocation = (location: string) => {
    setSearchState((prev) => ({ ...prev, location }))
  }

  const setPriceRange = (range: [number, number]) => {
    setSearchState((prev) => ({ ...prev, priceRange: range }))
  }

  const setSortBy = (sortBy: string) => {
    setSearchState((prev) => ({ ...prev, sortBy }))
  }

  const setOnlyInStock = (inStock: boolean) => {
    setSearchState((prev) => ({ ...prev, onlyInStock: inStock }))
  }

  const clearFilters = () => {
    setSearchState(initialState)
  }

  return (
    <SearchContext.Provider
      value={{
        searchState,
        setSearchTerm,
        setCategory,
        setLocation,
        setPriceRange,
        setSortBy,
        setOnlyInStock,
        clearFilters,
      }}
    >
      {children}
    </SearchContext.Provider>
  )
}

export function useSearch() {
  const context = useContext(SearchContext)
  if (!context) {
    throw new Error("useSearch must be used within a SearchProvider")
  }
  return context
}
