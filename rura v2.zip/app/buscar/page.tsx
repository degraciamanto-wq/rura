"use client"

import { useState } from "react"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Star, MapPin, MessageCircle, Filter, Grid, List, Search } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { AddToCartButton } from "@/components/cart/add-to-cart-button"

// Mock data - in real app this would come from API
const allProducts = [
  {
    id: 1,
    name: "Semillas de Tomate Cherry",
    producer: "Finca Los Robles",
    location: "Cundinamarca",
    price: 15000,
    rating: 4.8,
    reviews: 24,
    image: "/semillas-tomate-cherry.jpg",
    category: "Semillas",
    whatsapp: "+573001234567",
    description: "Semillas de tomate cherry de alta calidad, perfectas para cultivo en casa",
    tags: ["orgánico", "tomate", "cherry", "semillas", "huerto"],
  },
  {
    id: 2,
    name: "Quinoa Orgánica",
    producer: "Granja Verde",
    location: "Boyacá",
    price: 25000,
    rating: 4.9,
    reviews: 18,
    image: "/quinoa-organica.jpg",
    category: "Granos",
    whatsapp: "+573007654321",
    description: "Quinoa orgánica certificada, rica en proteínas y nutrientes",
    tags: ["quinoa", "orgánico", "proteína", "granos", "saludable"],
  },
  {
    id: 3,
    name: "Manzanas Rojas",
    producer: "Huerta San José",
    location: "Antioquia",
    price: 8000,
    rating: 4.7,
    reviews: 32,
    image: "/manzanas-rojas-frescas.jpg",
    category: "Frutas",
    whatsapp: "+573009876543",
    description: "Manzanas rojas frescas, cosechadas en el momento perfecto de maduración",
    tags: ["manzana", "fruta", "roja", "fresco", "antioquia"],
  },
  {
    id: 4,
    name: "Semillas de Lechuga",
    producer: "Cultivos del Valle",
    location: "Valle del Cauca",
    price: 12000,
    rating: 4.6,
    reviews: 15,
    image: "/semillas-lechuga.jpg",
    category: "Semillas",
    whatsapp: "+573005555555",
    description: "Semillas de lechuga variedad crespa, ideal para huertos urbanos",
    tags: ["lechuga", "semillas", "crespa", "huerto", "urbano"],
  },
  {
    id: 5,
    name: "Frijoles Rojos",
    producer: "Finca La Esperanza",
    location: "Nariño",
    price: 18000,
    rating: 4.8,
    reviews: 28,
    image: "/frijoles-rojos.jpg",
    category: "Granos",
    whatsapp: "+573006666666",
    description: "Frijoles rojos de excelente calidad, ricos en proteína vegetal",
    tags: ["frijoles", "rojos", "proteína", "granos", "vegetal"],
  },
  {
    id: 6,
    name: "Naranjas Valencia",
    producer: "Citricos del Sol",
    location: "Meta",
    price: 6000,
    rating: 4.9,
    reviews: 41,
    image: "/naranjas-valencia.jpg",
    category: "Frutas",
    whatsapp: "+573007777777",
    description: "Naranjas Valencia jugosas y dulces, perfectas para jugo natural",
    tags: ["naranja", "valencia", "jugo", "dulce", "cítrico"],
  },
]

const allProducers = [
  {
    id: 1,
    name: "Finca Los Robles",
    owner: "María García",
    location: "Cundinamarca",
    rating: 4.8,
    reviews: 45,
    image: "/finca-los-robles.jpg",
    specialties: ["Semillas orgánicas", "Hortalizas"],
    productsCount: 15,
  },
  {
    id: 2,
    name: "Granja Verde",
    owner: "Carlos Mendoza",
    location: "Boyacá",
    rating: 4.9,
    reviews: 32,
    image: "/granja-verde.jpg",
    specialties: ["Granos orgánicos", "Quinoa"],
    productsCount: 8,
  },
]

export default function SearchPage() {
  const searchParams = useSearchParams()
  const initialQuery = searchParams.get("q") || ""

  const [searchQuery, setSearchQuery] = useState(initialQuery)
  const [searchType, setSearchType] = useState<"all" | "products" | "producers">("all")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [sortBy, setSortBy] = useState("relevance")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [priceRange, setPriceRange] = useState<"all" | "low" | "medium" | "high">("all")

  const handleWhatsAppContact = (phone: string, productName: string) => {
    const message = encodeURIComponent(`Hola, estoy interesado en ${productName}`)
    window.open(`https://wa.me/${phone.replace("+", "")}?text=${message}`, "_blank")
  }

  // Advanced search function
  const searchItems = (items: any[], query: string, type: "products" | "producers") => {
    if (!query.trim()) return items

    const searchTerms = query.toLowerCase().split(" ")

    return items.filter((item) => {
      const searchableText =
        type === "products"
          ? `${item.name} ${item.producer} ${item.description} ${item.tags?.join(" ") || ""} ${item.category}`.toLowerCase()
          : `${item.name} ${item.owner} ${item.location} ${item.specialties?.join(" ") || ""}`.toLowerCase()

      return searchTerms.every((term) => searchableText.includes(term))
    })
  }

  const filteredProducts = searchItems(allProducts, searchQuery, "products")
    .filter((product) => selectedCategory === "all" || product.category === selectedCategory)
    .filter((product) => {
      if (priceRange === "all") return true
      if (priceRange === "low") return product.price < 10000
      if (priceRange === "medium") return product.price >= 10000 && product.price < 20000
      if (priceRange === "high") return product.price >= 20000
      return true
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "price-low":
          return a.price - b.price
        case "price-high":
          return b.price - a.price
        case "rating":
          return b.rating - a.rating
        case "name":
          return a.name.localeCompare(b.name)
        default: // relevance
          return 0
      }
    })

  const filteredProducers = searchItems(allProducers, searchQuery, "producers")

  const showProducts = searchType === "all" || searchType === "products"
  const showProducers = searchType === "all" || searchType === "producers"

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-forest mb-2">Resultados de búsqueda</h1>
        {searchQuery && (
          <p className="text-muted-foreground">
            Mostrando resultados para: <span className="font-semibold">"{searchQuery}"</span>
          </p>
        )}
      </div>

      {/* Advanced Search Bar */}
      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="flex flex-col gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar productos, productores..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 text-lg h-12"
              />
            </div>

            <div className="flex flex-wrap gap-4 items-center">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">Buscar en:</span>
                <Select value={searchType} onValueChange={(value: any) => setSearchType(value)}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todo</SelectItem>
                    <SelectItem value="products">Productos</SelectItem>
                    <SelectItem value="producers">Productores</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {showProducts && (
                <>
                  <div className="flex items-center gap-2">
                    <Filter className="h-4 w-4 text-muted-foreground" />
                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger className="w-32">
                        <SelectValue placeholder="Categoría" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todas</SelectItem>
                        <SelectItem value="Semillas">Semillas</SelectItem>
                        <SelectItem value="Granos">Granos</SelectItem>
                        <SelectItem value="Frutas">Frutas</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Select value={priceRange} onValueChange={(value: any) => setPriceRange(value)}>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="Precio" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos</SelectItem>
                      <SelectItem value="low">&lt; $10,000</SelectItem>
                      <SelectItem value="medium">$10,000 - $20,000</SelectItem>
                      <SelectItem value="high">&gt; $20,000</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Ordenar por" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="relevance">Relevancia</SelectItem>
                      <SelectItem value="name">Nombre</SelectItem>
                      <SelectItem value="price-low">Precio: Menor</SelectItem>
                      <SelectItem value="price-high">Precio: Mayor</SelectItem>
                      <SelectItem value="rating">Calificación</SelectItem>
                    </SelectContent>
                  </Select>

                  <div className="flex border rounded-md">
                    <Button
                      variant={viewMode === "grid" ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setViewMode("grid")}
                      className="rounded-r-none"
                    >
                      <Grid className="h-4 w-4" />
                    </Button>
                    <Button
                      variant={viewMode === "list" ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setViewMode("list")}
                      className="rounded-l-none"
                    >
                      <List className="h-4 w-4" />
                    </Button>
                  </div>
                </>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results Summary */}
      <div className="mb-6 text-sm text-muted-foreground">
        {showProducts && (
          <span>
            {filteredProducts.length} producto{filteredProducts.length !== 1 ? "s" : ""}
          </span>
        )}
        {showProducts && showProducers && <span> • </span>}
        {showProducers && (
          <span>
            {filteredProducers.length} productor{filteredProducers.length !== 1 ? "es" : ""}
          </span>
        )}
      </div>

      {/* Products Results */}
      {showProducts && filteredProducts.length > 0 && (
        <div className="mb-12">
          <h2 className="text-2xl font-heading font-bold text-forest mb-6">Productos</h2>
          <div className={viewMode === "grid" ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-4"}>
            {filteredProducts.map((product) => (
              <Card
                key={product.id}
                className={`overflow-hidden hover:shadow-lg transition-shadow ${viewMode === "list" ? "flex" : ""}`}
              >
                <div className={viewMode === "list" ? "w-48 flex-shrink-0" : "relative"}>
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    width={300}
                    height={200}
                    className={`object-cover ${viewMode === "list" ? "w-full h-full" : "w-full h-48"}`}
                  />
                  <Badge className="absolute top-2 left-2 bg-secondary text-secondary-foreground">
                    {product.category}
                  </Badge>
                </div>
                <div className="flex-1">
                  <CardContent className="p-4">
                    <h3 className="font-heading font-semibold text-lg mb-2 text-forest">
                      <Link href={`/productos/${product.id}`} className="hover:text-secondary">
                        {product.name}
                      </Link>
                    </h3>
                    <div className="flex items-center text-sm text-muted-foreground mb-2">
                      <MapPin className="w-4 h-4 mr-1" />
                      {product.producer} - {product.location}
                    </div>
                    <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{product.description}</p>
                    <div className="flex items-center mb-3">
                      <div className="flex items-center">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400 mr-1" />
                        <span className="text-sm font-medium">{product.rating}</span>
                        <span className="text-sm text-muted-foreground ml-1">({product.reviews} reseñas)</span>
                      </div>
                    </div>
                    <div className="text-2xl font-bold text-secondary mb-4">${product.price.toLocaleString()} COP</div>
                  </CardContent>
                  <CardFooter className="p-4 pt-0 flex gap-2">
                    <AddToCartButton
                      product={{
                        id: product.id,
                        name: product.name,
                        price: product.price,
                        image: product.image,
                        producer: product.producer,
                        category: product.category,
                      }}
                      className="flex-1"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleWhatsAppContact(product.whatsapp, product.name)}
                      className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground"
                    >
                      <MessageCircle className="w-4 h-4" />
                    </Button>
                  </CardFooter>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Producers Results */}
      {showProducers && filteredProducers.length > 0 && (
        <div className="mb-12">
          <h2 className="text-2xl font-heading font-bold text-forest mb-6">Productores</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducers.map((producer) => (
              <Card key={producer.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <Image
                      src={producer.image || "/placeholder.svg"}
                      alt={producer.name}
                      width={60}
                      height={60}
                      className="rounded-full mr-4"
                    />
                    <div>
                      <h3 className="font-heading font-semibold text-lg text-forest">
                        <Link href={`/productores/${producer.id}`} className="hover:text-secondary">
                          {producer.name}
                        </Link>
                      </h3>
                      <p className="text-sm text-muted-foreground">Por {producer.owner}</p>
                    </div>
                  </div>

                  <div className="flex items-center text-sm text-muted-foreground mb-3">
                    <MapPin className="w-4 h-4 mr-1" />
                    {producer.location}
                  </div>

                  <div className="flex items-center mb-3">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400 mr-1" />
                    <span className="text-sm font-medium">{producer.rating}</span>
                    <span className="text-sm text-muted-foreground ml-1">({producer.reviews} reseñas)</span>
                  </div>

                  <div className="flex flex-wrap gap-1 mb-4">
                    {producer.specialties.map((specialty) => (
                      <Badge key={specialty} variant="secondary" className="text-xs">
                        {specialty}
                      </Badge>
                    ))}
                  </div>

                  <p className="text-sm text-muted-foreground">{producer.productsCount} productos disponibles</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* No Results */}
      {((showProducts && filteredProducts.length === 0) || (showProducers && filteredProducers.length === 0)) && (
        <div className="text-center py-12">
          <div className="max-w-md mx-auto">
            <Search className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">No se encontraron resultados</h3>
            <p className="text-muted-foreground mb-6">Intenta con otros términos de búsqueda o ajusta los filtros.</p>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p>Sugerencias:</p>
              <ul className="list-disc list-inside space-y-1">
                <li>Verifica la ortografía</li>
                <li>Usa términos más generales</li>
                <li>Prueba con sinónimos</li>
                <li>Reduce los filtros aplicados</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
