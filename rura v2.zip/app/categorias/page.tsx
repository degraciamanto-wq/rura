"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Leaf, Wheat, Apple } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

const categories = [
  {
    id: "semillas",
    name: "Semillas",
    description: "Semillas de alta calidad para tu huerto",
    icon: Leaf,
    color: "text-green-600",
    bgColor: "bg-green-50",
    productCount: 45,
    image: "/semillas-tomate-cherry.jpg",
    subcategories: ["Hortalizas", "Aromáticas", "Flores", "Cereales"],
    featured: ["Tomate Cherry", "Albahaca", "Cilantro", "Lechuga"],
  },
  {
    id: "granos",
    name: "Granos",
    description: "Granos nutritivos y de excelente calidad",
    icon: Wheat,
    color: "text-amber-600",
    bgColor: "bg-amber-50",
    productCount: 32,
    image: "/quinoa-organica.jpg",
    subcategories: ["Legumbres", "Cereales", "Pseudocereales", "Frutos secos"],
    featured: ["Quinoa", "Frijoles", "Lentejas", "Arroz integral"],
  },
  {
    id: "frutas",
    name: "Frutas",
    description: "Frutas frescas directamente del productor",
    icon: Apple,
    color: "text-red-600",
    bgColor: "bg-red-50",
    productCount: 28,
    image: "/manzanas-rojas-frescas.jpg",
    subcategories: ["Cítricas", "Tropicales", "De clima frío", "Berries"],
    featured: ["Manzanas", "Naranjas", "Aguacates", "Fresas"],
  },
]

export default function CategoriesPage() {
  return (
    <div className="container py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-heading font-bold text-forest mb-4">Categorías de Productos</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Explora nuestra amplia variedad de productos agrícolas organizados por categorías
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
        {categories.map((category) => {
          const IconComponent = category.icon
          return (
            <Card key={category.id} className="overflow-hidden hover:shadow-lg transition-shadow group">
              <div className="relative">
                <Image
                  src={category.image || "/placeholder.svg"}
                  alt={category.name}
                  width={400}
                  height={200}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/30 transition-colors" />
                <div className="absolute top-4 left-4">
                  <div className={`p-3 rounded-full ${category.bgColor}`}>
                    <IconComponent className={`w-6 h-6 ${category.color}`} />
                  </div>
                </div>
                <div className="absolute bottom-4 left-4 text-white">
                  <h2 className="text-2xl font-heading font-bold mb-1">{category.name}</h2>
                  <p className="text-sm opacity-90">{category.productCount} productos disponibles</p>
                </div>
              </div>

              <CardContent className="p-6">
                <p className="text-muted-foreground mb-4">{category.description}</p>

                <div className="mb-4">
                  <h4 className="font-semibold mb-2 text-forest">Subcategorías:</h4>
                  <div className="flex flex-wrap gap-1">
                    {category.subcategories.map((sub) => (
                      <Badge key={sub} variant="outline" className="text-xs">
                        {sub}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="mb-6">
                  <h4 className="font-semibold mb-2 text-forest">Productos destacados:</h4>
                  <div className="space-y-1">
                    {category.featured.map((product) => (
                      <div key={product} className="text-sm text-muted-foreground">
                        • {product}
                      </div>
                    ))}
                  </div>
                </div>

                <Link
                  href={`/productos?categoria=${category.id}`}
                  className="inline-flex items-center justify-center w-full px-4 py-2 bg-secondary text-secondary-foreground rounded-md hover:bg-secondary/90 transition-colors font-medium"
                >
                  Ver productos de {category.name}
                </Link>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-secondary mb-2">105</div>
            <div className="text-muted-foreground">Total de productos</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-secondary mb-2">25</div>
            <div className="text-muted-foreground">Productores activos</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6 text-center">
            <div className="text-3xl font-bold text-secondary mb-2">12</div>
            <div className="text-muted-foreground">Departamentos</div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
