"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Star, MapPin, MessageCircle, Phone, Mail, Award, Heart } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useParams } from "next/navigation"
import { AddToCartButton } from "@/components/cart/add-to-cart-button"

// Mock data - in real app this would come from API
const getProducer = (id: string) => {
  const producers = [
    {
      id: 1,
      name: "Finca Los Robles",
      owner: "María García",
      location: "Cundinamarca",
      rating: 4.8,
      reviews: 45,
      image: "/finca-los-robles.jpg",
      coverImage: "/finca-los-robles-cover.jpg",
      specialties: ["Semillas orgánicas", "Hortalizas", "Plantas aromáticas"],
      experience: "20+ años",
      whatsapp: "+573001234567",
      email: "finca@losrobles.com",
      phone: "+573001234567",
      description:
        "Somos una finca familiar ubicada en las montañas de Cundinamarca, dedicada a la producción de semillas orgánicas certificadas desde hace más de 20 años. Nuestra pasión es ofrecer productos de la más alta calidad, cultivados con métodos tradicionales y sostenibles.",
      productsCount: 15,
      followers: 234,
      joinedDate: "2020-03-15",
      certifications: ["Orgánico USDA", "Fair Trade", "Rainforest Alliance"],
      story:
        "Todo comenzó cuando mi abuela me enseñó los secretos de la agricultura tradicional. Desde entonces, hemos mantenido viva esa tradición, combinándola con técnicas modernas de agricultura sostenible.",
      products: [
        {
          id: 1,
          name: "Semillas de Tomate Cherry",
          price: 15000,
          image: "/semillas-tomate-cherry.jpg",
          category: "Semillas",
          rating: 4.8,
          reviews: 24,
        },
        {
          id: 5,
          name: "Semillas de Albahaca",
          price: 12000,
          image: "/semillas-albahaca.jpg",
          category: "Semillas",
          rating: 4.7,
          reviews: 18,
        },
        {
          id: 6,
          name: "Semillas de Cilantro",
          price: 10000,
          image: "/semillas-cilantro.jpg",
          category: "Semillas",
          rating: 4.9,
          reviews: 22,
        },
      ],
    },
  ]

  return producers.find((p) => p.id === Number.parseInt(id))
}

export default function ProducerDetailPage() {
  const params = useParams()
  const producer = getProducer(params.id as string)
  const [isFollowing, setIsFollowing] = useState(false)

  if (!producer) {
    return (
      <div className="container py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Productor no encontrado</h1>
          <Link href="/productores">
            <Button>Volver a productores</Button>
          </Link>
        </div>
      </div>
    )
  }

  const handleWhatsAppContact = () => {
    const message = encodeURIComponent(`Hola, me interesa conocer más sobre ${producer.name}`)
    window.open(`https://wa.me/${producer.whatsapp.replace("+", "")}?text=${message}`, "_blank")
  }

  const handleFollow = () => {
    setIsFollowing(!isFollowing)
  }

  return (
    <div className="container py-8">
      {/* Cover Image */}
      <div className="relative h-64 md:h-80 rounded-lg overflow-hidden mb-8">
        <Image
          src={producer.coverImage || "/placeholder.svg"}
          alt={`${producer.name} cover`}
          fill
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="absolute bottom-4 left-4 text-white">
          <h1 className="text-3xl font-heading font-bold mb-2">{producer.name}</h1>
          <p className="text-lg">Por {producer.owner}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2">
          <Tabs defaultValue="about" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="about">Acerca de</TabsTrigger>
              <TabsTrigger value="products">Productos</TabsTrigger>
              <TabsTrigger value="reviews">Reseñas</TabsTrigger>
            </TabsList>

            <TabsContent value="about" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="font-heading text-forest">Nuestra Historia</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">{producer.description}</p>
                  <p className="text-muted-foreground">{producer.story}</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="font-heading text-forest">Especialidades</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {producer.specialties.map((specialty) => (
                      <Badge key={specialty} className="bg-secondary text-secondary-foreground">
                        {specialty}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="font-heading text-forest">Certificaciones</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {producer.certifications.map((cert) => (
                      <div key={cert} className="flex items-center">
                        <Award className="w-4 h-4 mr-2 text-secondary" />
                        <span>{cert}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="products" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {producer.products.map((product) => (
                  <Card key={product.id} className="overflow-hidden">
                    <div className="relative">
                      <Image
                        src={product.image || "/placeholder.svg"}
                        alt={product.name}
                        width={200}
                        height={150}
                        className="w-full h-32 object-cover"
                      />
                      <Badge className="absolute top-2 left-2 bg-secondary text-secondary-foreground">
                        {product.category}
                      </Badge>
                    </div>
                    <CardContent className="p-4">
                      <h4 className="font-heading font-semibold mb-2">
                        <Link href={`/productos/${product.id}`} className="hover:text-secondary">
                          {product.name}
                        </Link>
                      </h4>
                      <div className="flex items-center mb-2">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400 mr-1" />
                        <span className="text-sm">{product.rating}</span>
                        <span className="text-sm text-muted-foreground ml-1">({product.reviews})</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-bold text-secondary">${product.price.toLocaleString()}</span>
                        <AddToCartButton
                          product={{
                            id: product.id,
                            name: product.name,
                            price: product.price,
                            image: product.image,
                            producer: producer.name,
                            category: product.category,
                          }}
                          size="sm"
                        />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="reviews" className="space-y-6">
              <div className="text-center py-8">
                <p className="text-muted-foreground">Sistema de reseñas en desarrollo</p>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Producer Info Card */}
          <Card>
            <CardContent className="p-6">
              <div className="text-center mb-4">
                <Image
                  src={producer.image || "/placeholder.svg"}
                  alt={producer.name}
                  width={80}
                  height={80}
                  className="rounded-full mx-auto mb-3"
                />
                <div className="flex items-center justify-center mb-2">
                  <Star className="w-5 h-5 fill-yellow-400 text-yellow-400 mr-1" />
                  <span className="text-lg font-semibold">{producer.rating}</span>
                  <span className="text-muted-foreground ml-1">({producer.reviews} reseñas)</span>
                </div>
                <div className="flex items-center justify-center text-muted-foreground mb-4">
                  <MapPin className="w-4 h-4 mr-1" />
                  {producer.location}
                </div>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Experiencia:</span>
                  <span className="font-medium">{producer.experience}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Productos:</span>
                  <span className="font-medium">{producer.productsCount}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Seguidores:</span>
                  <span className="font-medium">{producer.followers}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Miembro desde:</span>
                  <span className="font-medium">
                    {new Date(producer.joinedDate).toLocaleDateString("es-ES", {
                      year: "numeric",
                      month: "long",
                    })}
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <Button
                  onClick={handleFollow}
                  variant={isFollowing ? "outline" : "default"}
                  className="w-full bg-secondary hover:bg-secondary/90"
                >
                  <Heart className={`w-4 h-4 mr-2 ${isFollowing ? "fill-current" : ""}`} />
                  {isFollowing ? "Siguiendo" : "Seguir"}
                </Button>
                <Button variant="outline" onClick={handleWhatsAppContact} className="w-full bg-transparent">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Contactar por WhatsApp
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Contact Info */}
          <Card>
            <CardHeader>
              <CardTitle className="font-heading text-forest">Información de Contacto</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center">
                <MessageCircle className="w-4 h-4 mr-3 text-green-600" />
                <span className="text-sm">{producer.whatsapp}</span>
              </div>
              <div className="flex items-center">
                <Phone className="w-4 h-4 mr-3 text-muted-foreground" />
                <span className="text-sm">{producer.phone}</span>
              </div>
              <div className="flex items-center">
                <Mail className="w-4 h-4 mr-3 text-muted-foreground" />
                <span className="text-sm">{producer.email}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
