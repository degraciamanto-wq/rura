"use client"

import { useState } from "react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Star, MapPin, MessageCircle, Users, Sprout } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

const producers = [
  {
    id: 1,
    name: "Finca Los Robles",
    owner: "María García",
    location: "Cundinamarca",
    rating: 4.8,
    reviews: 45,
    image: "/finca-los-robles.jpg",
    specialties: ["Semillas orgánicas", "Hortalizas", "Plantas aromáticas"],
    experience: "20+ años",
    whatsapp: "+573001234567",
    email: "finca@losrobles.com",
    phone: "+573001234567",
    description: "Finca familiar dedicada a la producción de semillas orgánicas certificadas.",
    productsCount: 15,
    followers: 234,
  },
  {
    id: 2,
    name: "Granja Verde",
    owner: "Carlos Mendoza",
    location: "Boyacá",
    rating: 4.9,
    reviews: 32,
    image: "/granja-verde.jpg",
    specialties: ["Granos andinos", "Quinoa", "Amaranto"],
    experience: "15+ años",
    whatsapp: "+573007654321",
    email: "info@granjaverde.com",
    phone: "+573007654321",
    description: "Especialistas en granos andinos con certificación orgánica internacional.",
    productsCount: 8,
    followers: 189,
  },
  {
    id: 3,
    name: "Huerta San José",
    owner: "Ana Rodríguez",
    location: "Antioquia",
    rating: 4.7,
    reviews: 67,
    image: "/huerta-san-jose.jpg",
    specialties: ["Frutas frescas", "Cítricos", "Frutas tropicales"],
    experience: "25+ años",
    whatsapp: "+573009876543",
    email: "contacto@huertasanjose.com",
    phone: "+573009876543",
    description: "Huerta familiar con tradición en el cultivo de frutas frescas de temporada.",
    productsCount: 22,
    followers: 456,
  },
  {
    id: 4,
    name: "Cultivos del Valle",
    owner: "Pedro Jiménez",
    location: "Valle del Cauca",
    rating: 4.6,
    reviews: 28,
    image: "/cultivos-valle.jpg",
    specialties: ["Verduras de hoja", "Lechugas", "Espinacas"],
    experience: "12+ años",
    whatsapp: "+573005555555",
    email: "pedro@cultivosdelvalle.com",
    phone: "+573005555555",
    description: "Cultivos hidropónicos especializados en verduras de hoja verde.",
    productsCount: 12,
    followers: 167,
  },
]

export default function ProducersPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedLocation, setSelectedLocation] = useState("all")
  const [sortBy, setSortBy] = useState("rating")

  const handleWhatsAppContact = (phone: string, producerName: string) => {
    const message = encodeURIComponent(`Hola, me interesa conocer más sobre ${producerName}`)
    window.open(`https://wa.me/${phone.replace("+", "")}?text=${message}`, "_blank")
  }

  const filteredProducers = producers
    .filter(
      (producer) =>
        producer.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
        (selectedLocation === "all" || producer.location === selectedLocation),
    )
    .sort((a, b) => {
      switch (sortBy) {
        case "rating":
          return b.rating - a.rating
        case "reviews":
          return b.reviews - a.reviews
        case "products":
          return b.productsCount - a.productsCount
        default:
          return a.name.localeCompare(b.name)
      }
    })

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-forest mb-4">Nuestros Productores</h1>
        <p className="text-muted-foreground">
          Conoce a los productores locales que hacen posible nuestro marketplace agrícola
        </p>
      </div>

      {/* Filters */}
      <div className="mb-8 p-4 bg-muted/30 rounded-lg">
        <div className="flex flex-col md:flex-row gap-4 items-center">
          <div className="flex-1">
            <Input
              placeholder="Buscar productores..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>
          <div className="flex gap-2 items-center">
            <Select value={selectedLocation} onValueChange={setSelectedLocation}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Ubicación" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                <SelectItem value="Cundinamarca">Cundinamarca</SelectItem>
                <SelectItem value="Boyacá">Boyacá</SelectItem>
                <SelectItem value="Antioquia">Antioquia</SelectItem>
                <SelectItem value="Valle del Cauca">Valle del Cauca</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Ordenar por" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="rating">Calificación</SelectItem>
                <SelectItem value="reviews">Reseñas</SelectItem>
                <SelectItem value="products">Productos</SelectItem>
                <SelectItem value="name">Nombre</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Producers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProducers.map((producer) => (
          <Card key={producer.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="relative">
              <Image
                src={producer.image || "/placeholder.svg"}
                alt={producer.name}
                width={300}
                height={200}
                className="w-full h-48 object-cover"
              />
              <div className="absolute top-2 right-2 bg-background/90 rounded-full px-2 py-1 text-xs font-medium">
                {producer.experience}
              </div>
            </div>
            <CardContent className="p-4">
              <h3 className="font-heading font-semibold text-lg mb-1 text-forest">
                <Link href={`/productores/${producer.id}`} className="hover:text-secondary">
                  {producer.name}
                </Link>
              </h3>
              <p className="text-sm text-muted-foreground mb-2">Por {producer.owner}</p>
              <div className="flex items-center text-sm text-muted-foreground mb-3">
                <MapPin className="w-4 h-4 mr-1" />
                {producer.location}
              </div>
              <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{producer.description}</p>
              <div className="flex items-center mb-3">
                <Star className="w-4 h-4 fill-yellow-400 text-yellow-400 mr-1" />
                <span className="text-sm font-medium">{producer.rating}</span>
                <span className="text-sm text-muted-foreground ml-1">({producer.reviews} reseñas)</span>
              </div>
              <div className="flex items-center justify-between text-sm mb-4">
                <div className="flex items-center">
                  <Sprout className="w-4 h-4 mr-1 text-secondary" />
                  <span>{producer.productsCount} productos</span>
                </div>
                <div className="flex items-center">
                  <Users className="w-4 h-4 mr-1 text-muted-foreground" />
                  <span>{producer.followers} seguidores</span>
                </div>
              </div>
              <div className="flex flex-wrap gap-1 mb-4">
                {producer.specialties.slice(0, 2).map((specialty) => (
                  <Badge key={specialty} variant="outline" className="text-xs">
                    {specialty}
                  </Badge>
                ))}
                {producer.specialties.length > 2 && (
                  <Badge variant="outline" className="text-xs">
                    +{producer.specialties.length - 2}
                  </Badge>
                )}
              </div>
            </CardContent>
            <CardFooter className="p-4 pt-0 flex gap-2">
              <Button asChild className="flex-1 bg-secondary hover:bg-secondary/90">
                <Link href={`/productores/${producer.id}`}>Ver Perfil</Link>
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleWhatsAppContact(producer.whatsapp, producer.name)}
                className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground"
              >
                <MessageCircle className="w-4 h-4" />
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {filteredProducers.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No se encontraron productores que coincidan con tu búsqueda.</p>
        </div>
      )}
    </div>
  )
}
