"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Star, MapPin, MessageCircle, Phone, Mail, Minus, Plus } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useParams } from "next/navigation"
import { AddToCartButton } from "@/components/cart/add-to-cart-button"

// Mock data - in real app this would come from API
const getProduct = (id: string) => {
  const products = [
    {
      id: 1,
      name: "Semillas de Tomate Cherry",
      producer: "Finca Los Robles",
      location: "Cundinamarca",
      price: 15000,
      rating: 4.8,
      reviews: 24,
      image: "/semillas-tomate-cherry.jpg",
      category: "Semillas",
      whatsapp: "+573001234567",
      email: "finca@losrobles.com",
      phone: "+573001234567",
      description:
        "Semillas de tomate cherry de alta calidad, perfectas para cultivo en casa. Estas semillas han sido seleccionadas cuidadosamente para garantizar una alta tasa de germinación y plantas saludables.",
      specifications: {
        Variedad: "Cherry",
        "Tiempo de germinación": "7-14 días",
        "Tiempo de cosecha": "60-80 días",
        Cantidad: "50 semillas",
        Certificación: "Orgánico",
      },
      producerInfo: {
        name: "Finca Los Robles",
        description:
          "Somos una finca familiar dedicada a la producción de semillas orgánicas desde hace más de 20 años.",
        experience: "20+ años",
        specialties: ["Semillas orgánicas", "Hortalizas", "Plantas aromáticas"],
      },
    },
  ]

  return products.find((p) => p.id === Number.parseInt(id))
}

export default function ProductDetailPage() {
  const params = useParams()
  const product = getProduct(params.id as string)
  const [quantity, setQuantity] = useState(1)

  if (!product) {
    return (
      <div className="container py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Producto no encontrado</h1>
          <Link href="/productos">
            <Button>Volver al catálogo</Button>
          </Link>
        </div>
      </div>
    )
  }

  const handleWhatsAppContact = () => {
    const message = encodeURIComponent(`Hola, estoy interesado en ${product.name}. Cantidad: ${quantity}`)
    window.open(`https://wa.me/${product.whatsapp.replace("+", "")}?text=${message}`, "_blank")
  }

  const handleQuantityChange = (delta: number) => {
    setQuantity(Math.max(1, quantity + delta))
  }

  return (
    <div className="container py-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Product Image */}
        <div className="space-y-4">
          <div className="relative">
            <Image
              src={product.image || "/placeholder.svg"}
              alt={product.name}
              width={600}
              height={400}
              className="w-full h-96 object-cover rounded-lg"
            />
            <Badge className="absolute top-4 left-4 bg-secondary text-secondary-foreground">{product.category}</Badge>
          </div>
        </div>

        {/* Product Info */}
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-heading font-bold text-forest mb-2">{product.name}</h1>
            <div className="flex items-center text-muted-foreground mb-4">
              <MapPin className="w-4 h-4 mr-1" />
              {product.producer} - {product.location}
            </div>
            <div className="flex items-center mb-4">
              <div className="flex items-center">
                <Star className="w-5 h-5 fill-yellow-400 text-yellow-400 mr-1" />
                <span className="text-lg font-medium">{product.rating}</span>
                <span className="text-muted-foreground ml-2">({product.reviews} reseñas)</span>
              </div>
            </div>
            <div className="text-3xl font-bold text-secondary mb-6">${product.price.toLocaleString()} COP</div>
          </div>

          <div>
            <h3 className="font-heading font-semibold text-lg mb-2">Descripción</h3>
            <p className="text-muted-foreground">{product.description}</p>
          </div>

          {/* Quantity and Add to Cart */}
          <div className="space-y-4">
            <div className="flex items-center space-x-4">
              <span className="font-medium">Cantidad:</span>
              <div className="flex items-center border rounded-md">
                <Button variant="ghost" size="sm" onClick={() => handleQuantityChange(-1)} disabled={quantity <= 1}>
                  <Minus className="h-4 w-4" />
                </Button>
                <span className="px-4 py-2 min-w-[3rem] text-center">{quantity}</span>
                <Button variant="ghost" size="sm" onClick={() => handleQuantityChange(1)}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="flex gap-3">
              <AddToCartButton
                product={{
                  id: product.id,
                  name: product.name,
                  price: product.price,
                  image: product.image,
                  producer: product.producer,
                  category: product.category,
                }}
                quantity={quantity}
                className="flex-1"
              />
              <Button
                variant="outline"
                onClick={handleWhatsAppContact}
                className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground bg-transparent"
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Contactar
              </Button>
            </div>
          </div>
        </div>
      </div>

      <Separator className="my-8" />

      {/* Product Specifications */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card>
          <CardContent className="p-6">
            <h3 className="font-heading font-semibold text-lg mb-4">Especificaciones</h3>
            <div className="space-y-3">
              {Object.entries(product.specifications).map(([key, value]) => (
                <div key={key} className="flex justify-between">
                  <span className="text-muted-foreground">{key}:</span>
                  <span className="font-medium">{value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h3 className="font-heading font-semibold text-lg mb-4">Información del Productor</h3>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium text-forest">{product.producerInfo.name}</h4>
                <p className="text-sm text-muted-foreground mt-1">{product.producerInfo.description}</p>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Experiencia:</span>
                <span className="font-medium">{product.producerInfo.experience}</span>
              </div>
              <div>
                <span className="text-sm text-muted-foreground">Especialidades:</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {product.producerInfo.specialties.map((specialty) => (
                    <Badge key={specialty} variant="outline" className="text-xs">
                      {specialty}
                    </Badge>
                  ))}
                </div>
              </div>
              <Separator />
              <div className="space-y-2">
                <div className="flex items-center text-sm">
                  <MessageCircle className="w-4 h-4 mr-2 text-green-600" />
                  <span>{product.whatsapp}</span>
                </div>
                <div className="flex items-center text-sm">
                  <Phone className="w-4 h-4 mr-2 text-muted-foreground" />
                  <span>{product.phone}</span>
                </div>
                <div className="flex items-center text-sm">
                  <Mail className="w-4 h-4 mr-2 text-muted-foreground" />
                  <span>{product.email}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
