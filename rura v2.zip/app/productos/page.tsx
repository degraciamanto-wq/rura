"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Star, MapPin, MessageCircle, Filter, Grid, List } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

const products = [
  {
    id: 1,
    name: "Semillas de Tomate Cherry",
    producer: "Finca Los Robles",
    location: "Cundinamarca",
    price: 15000,
    rating: 4.8,
    reviews: 24,
    image: "/semillas-tomate-cherry.jpg",
    category: "Semillas",
    whatsapp: "+573001234567",
    description: "Semillas de tomate cherry de alta calidad, perfectas para cultivo en casa",
  },
  {
    id: 2,
    name: "Quinoa Orgánica",
    producer: "Granja Verde",
    location: "Boyacá",
    price: 25000,
    rating: 4.9,
    reviews: 18,
    image: "/quinoa-organica.jpg",
    category: "Granos",
    whatsapp: "+573007654321",
    description: "Quinoa orgánica certificada, rica en proteínas y nutrientes",
  },
  {
    id: 3,
    name: "Manzanas Rojas",
    producer: "Huerta San José",
    location: "Antioquia",
    price: 8000,
    rating: 4.7,
    reviews: 32,
    image: "/manzanas-rojas-frescas.jpg",
    category: "Frutas",
    whatsapp: "+573009876543",
    description: "Manzanas rojas frescas, cosechadas en el momento perfecto de maduración",
  },
  {
    id: 4,
    name: "Semillas de Lechuga",
    producer: "Cultivos del Valle",
    location: "Valle del Cauca",
    price: 12000,
    rating: 4.6,
    reviews: 15,
    image: "/semillas-lechuga.jpg",
    category: "Semillas",
    whatsapp: "+573005555555",
    description: "Semillas de lechuga variedad crespa, ideal para huertos urbanos",
  },
  {
    id: 5,
    name: "Frijoles Rojos",
    producer: "Finca La Esperanza",
    location: "Nariño",
    price: 18000,
    rating: 4.8,
    reviews: 28,
    image: "/frijoles-rojos.jpg",
    category: "Granos",
    whatsapp: "+573006666666",
    description: "Frijoles rojos de excelente calidad, ricos en proteína vegetal",
  },
  {
    id: 6,
    name: "Naranjas Valencia",
    producer: "Citricos del Sol",
    location: "Meta",
    price: 6000,
    rating: 4.9,
    reviews: 41,
    image: "/naranjas-valencia.jpg",
    category: "Frutas",
    whatsapp: "+573007777777",
    description: "Naranjas Valencia jugosas y dulces, perfectas para jugo natural",
  },
]

export default function ProductsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [sortBy, setSortBy] = useState("name")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")

  const handleWhatsAppContact = (phone: string, productName: string) => {
    const message = encodeURIComponent(`Hola, estoy interesado en ${productName}`)
    window.open(`https://wa.me/${phone.replace("+", "")}?text=${message}`, "_blank")
  }

  const filteredProducts = products
    .filter(
      (product) =>
        product.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
        (selectedCategory === "all" || product.category === selectedCategory),
    )
    .sort((a, b) => {
      switch (sortBy) {
        case "price-low":
          return a.price - b.price
        case "price-high":
          return b.price - a.price
        case "rating":
          return b.rating - a.rating
        default:
          return a.name.localeCompare(b.name)
      }
    })

  return (
    <div className="container py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-forest mb-4">Catálogo de Productos</h1>
        <p className="text-muted-foreground">Descubre productos agrícolas frescos directamente de los productores</p>
      </div>

      {/* Filters */}
      <div className="mb-8 p-4 bg-muted/30 rounded-lg">
        <div className="flex flex-col md:flex-row gap-4 items-center">
          <div className="flex-1">
            <Input
              placeholder="Buscar productos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
          </div>
          <div className="flex gap-2 items-center">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Categoría" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                <SelectItem value="Semillas">Semillas</SelectItem>
                <SelectItem value="Granos">Granos</SelectItem>
                <SelectItem value="Frutas">Frutas</SelectItem>
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Ordenar por" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="name">Nombre</SelectItem>
                <SelectItem value="price-low">Precio: Menor</SelectItem>
                <SelectItem value="price-high">Precio: Mayor</SelectItem>
                <SelectItem value="rating">Calificación</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex border rounded-md">
              <Button
                variant={viewMode === "grid" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("grid")}
                className="rounded-r-none"
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === "list" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("list")}
                className="rounded-l-none"
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Products Grid/List */}
      <div className={viewMode === "grid" ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-4"}>
        {filteredProducts.map((product) => (
          <Card
            key={product.id}
            className={`overflow-hidden hover:shadow-lg transition-shadow ${viewMode === "list" ? "flex" : ""}`}
          >
            <div className={viewMode === "list" ? "w-48 flex-shrink-0" : "relative"}>
              <Image
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                width={300}
                height={200}
                className={`object-cover ${viewMode === "list" ? "w-full h-full" : "w-full h-48"}`}
              />
              <Badge className="absolute top-2 left-2 bg-secondary text-secondary-foreground">{product.category}</Badge>
            </div>
            <div className="flex-1">
              <CardContent className="p-4">
                <h3 className="font-heading font-semibold text-lg mb-2 text-forest">
                  <Link href={`/productos/${product.id}`} className="hover:text-secondary">
                    {product.name}
                  </Link>
                </h3>
                <div className="flex items-center text-sm text-muted-foreground mb-2">
                  <MapPin className="w-4 h-4 mr-1" />
                  {product.producer} - {product.location}
                </div>
                <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{product.description}</p>
                <div className="flex items-center mb-3">
                  <div className="flex items-center">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400 mr-1" />
                    <span className="text-sm font-medium">{product.rating}</span>
                    <span className="text-sm text-muted-foreground ml-1">({product.reviews} reseñas)</span>
                  </div>
                </div>
                <div className="text-2xl font-bold text-secondary mb-4">${product.price.toLocaleString()} COP</div>
              </CardContent>
              <CardFooter className="p-4 pt-0 flex gap-2">
                <Button className="flex-1 bg-secondary hover:bg-secondary/90">Agregar al Carrito</Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleWhatsAppContact(product.whatsapp, product.name)}
                  className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground"
                >
                  <MessageCircle className="w-4 h-4" />
                </Button>
              </CardFooter>
            </div>
          </Card>
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No se encontraron productos que coincidan con tu búsqueda.</p>
        </div>
      )}
    </div>
  )
}
