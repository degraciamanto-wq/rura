"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Star, User, Calendar, ThumbsUp, MessageSquare } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"

// Mock reviews data
const mockReviews = [
  {
    id: 1,
    user: "Ana Rodríguez",
    rating: 5,
    date: "2024-01-15",
    title: "Excelente experiencia con RURA",
    content:
      "He comprado semillas de tomate y quinoa a través de RURA y la experiencia ha sido fantástica. Los productos llegaron en perfecto estado y la calidad es excepcional. El contacto directo con los productores hace toda la diferencia.",
    likes: 12,
    helpful: true,
    verified: true,
    category: "Experiencia general",
  },
  {
    id: 2,
    user: "Carlos Mendoza",
    rating: 4,
    date: "2024-01-10",
    title: "Buena plataforma, mejorable en tiempos de entrega",
    content:
      "La plataforma es muy fácil de usar y me encanta poder contactar directamente a los productores por WhatsApp. Los productos son de excelente calidad, aunque los tiempos de entrega podrían mejorar un poco.",
    likes: 8,
    helpful: false,
    verified: true,
    category: "Logística",
  },
  {
    id: 3,
    user: "María González",
    rating: 5,
    date: "2024-01-08",
    title: "Apoyo real a los productores locales",
    content:
      "Me parece una iniciativa maravillosa que conecta directamente a consumidores con productores. He conocido fincas increíbles y productos que no encontraría en otro lugar. Totalmente recomendado.",
    likes: 15,
    helpful: true,
    verified: true,
    category: "Impacto social",
  },
  {
    id: 4,
    user: "Diego Herrera",
    rating: 4,
    date: "2024-01-05",
    title: "Productos frescos y de calidad",
    content:
      "Compré frutas y granos, todo llegó fresco y con excelente presentación. El sistema de puntuación de productores es muy útil para tomar decisiones de compra.",
    likes: 6,
    helpful: false,
    verified: false,
    category: "Calidad del producto",
  },
]

const categories = ["Todas", "Experiencia general", "Calidad del producto", "Logística", "Impacto social"]

export default function ReviewsPage() {
  const { user } = useAuth()
  const [selectedCategory, setSelectedCategory] = useState("Todas")
  const [showReviewForm, setShowReviewForm] = useState(false)
  const [newReview, setNewReview] = useState({
    rating: 0,
    title: "",
    content: "",
    category: "Experiencia general",
  })

  const filteredReviews =
    selectedCategory === "Todas" ? mockReviews : mockReviews.filter((review) => review.category === selectedCategory)

  const averageRating = mockReviews.reduce((acc, review) => acc + review.rating, 0) / mockReviews.length

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would submit the review to your backend
    console.log("Submitting review:", newReview)
    setShowReviewForm(false)
    setNewReview({ rating: 0, title: "", content: "", category: "Experiencia general" })
  }

  const handleRatingClick = (rating: number) => {
    setNewReview((prev) => ({ ...prev, rating }))
  }

  return (
    <div className="container py-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-heading font-bold text-forest mb-4">Reseñas de RURA</h1>
          <p className="text-lg text-muted-foreground mb-6">Conoce las experiencias de nuestra comunidad</p>

          {/* Overall Rating */}
          <Card className="max-w-md mx-auto mb-6">
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center mb-2">
                <span className="text-3xl font-bold mr-2">{averageRating.toFixed(1)}</span>
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`w-6 h-6 ${
                        star <= averageRating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
              </div>
              <p className="text-muted-foreground">Basado en {mockReviews.length} reseñas</p>
            </CardContent>
          </Card>

          {user && (
            <Button onClick={() => setShowReviewForm(!showReviewForm)} className="bg-secondary hover:bg-secondary/90">
              <MessageSquare className="w-4 h-4 mr-2" />
              Escribir reseña
            </Button>
          )}
        </div>

        {/* Review Form */}
        {showReviewForm && user && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="font-heading text-forest">Comparte tu experiencia</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmitReview} className="space-y-4">
                <div>
                  <Label htmlFor="rating">Calificación</Label>
                  <div className="flex mt-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button key={star} type="button" onClick={() => handleRatingClick(star)} className="p-1">
                        <Star
                          className={`w-6 h-6 ${
                            star <= newReview.rating
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-gray-300 hover:text-yellow-400"
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <Label htmlFor="category">Categoría</Label>
                  <select
                    value={newReview.category}
                    onChange={(e) => setNewReview((prev) => ({ ...prev, category: e.target.value }))}
                    className="w-full mt-1 p-2 border rounded-md"
                  >
                    {categories.slice(1).map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <Label htmlFor="title">Título de la reseña</Label>
                  <Input
                    id="title"
                    value={newReview.title}
                    onChange={(e) => setNewReview((prev) => ({ ...prev, title: e.target.value }))}
                    placeholder="Resume tu experiencia en pocas palabras"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="content">Tu reseña</Label>
                  <Textarea
                    id="content"
                    value={newReview.content}
                    onChange={(e) => setNewReview((prev) => ({ ...prev, content: e.target.value }))}
                    placeholder="Cuéntanos sobre tu experiencia con RURA..."
                    rows={4}
                    required
                  />
                </div>

                <div className="flex gap-2">
                  <Button type="submit" className="bg-secondary hover:bg-secondary/90">
                    Publicar reseña
                  </Button>
                  <Button type="button" variant="outline" onClick={() => setShowReviewForm(false)}>
                    Cancelar
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Category Filter */}
        <div className="flex flex-wrap gap-2 mb-6">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              className={selectedCategory === category ? "bg-secondary hover:bg-secondary/90" : ""}
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Reviews List */}
        <div className="space-y-6">
          {filteredReviews.map((review) => (
            <Card key={review.id}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-secondary/20 rounded-full flex items-center justify-center mr-3">
                      <User className="w-5 h-5 text-secondary" />
                    </div>
                    <div>
                      <div className="flex items-center">
                        <h4 className="font-semibold mr-2">{review.user}</h4>
                        {review.verified && (
                          <Badge variant="secondary" className="text-xs">
                            Verificado
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Calendar className="w-3 h-3 mr-1" />
                        {new Date(review.date).toLocaleDateString("es-ES", {
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}
                      </div>
                    </div>
                  </div>
                  <Badge variant="outline">{review.category}</Badge>
                </div>

                <div className="flex items-center mb-3">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`w-4 h-4 ${
                        star <= review.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                      }`}
                    />
                  ))}
                  <span className="ml-2 font-semibold">{review.rating}/5</span>
                </div>

                <h3 className="font-semibold text-lg mb-2">{review.title}</h3>
                <p className="text-muted-foreground mb-4">{review.content}</p>

                <div className="flex items-center justify-between">
                  <button className="flex items-center text-sm text-muted-foreground hover:text-secondary">
                    <ThumbsUp className="w-4 h-4 mr-1" />
                    Útil ({review.likes})
                  </button>
                  {review.helpful && (
                    <Badge variant="secondary" className="text-xs">
                      Marcada como útil
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredReviews.length === 0 && (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No hay reseñas en esta categoría aún.</p>
          </div>
        )}
      </div>
    </div>
  )
}
