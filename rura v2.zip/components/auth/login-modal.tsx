"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { User, Store, Eye, EyeOff } from "lucide-react"

interface LoginModalProps {
  isOpen: boolean
  onClose: () => void
  onLogin: (userType: "consumer" | "producer", userData: any) => void
}

export function LoginModal({ isOpen, onClose, onLogin }: LoginModalProps) {
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("consumer")

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>, userType: "consumer" | "producer") => {
    e.preventDefault()
    setIsLoading(true)

    const formData = new FormData(e.currentTarget)
    const email = formData.get("email") as string
    const password = formData.get("password") as string

    // Simulate API call
    setTimeout(() => {
      const userData = {
        email,
        userType,
        name: userType === "consumer" ? "Juan Pérez" : "Finca Los Robles",
        id: Math.random().toString(36).substr(2, 9),
      }

      onLogin(userType, userData)
      setIsLoading(false)
      onClose()
    }, 1000)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-heading text-xl text-forest">Iniciar Sesión en RURA</DialogTitle>
          <DialogDescription>Elige tu tipo de cuenta para acceder a la plataforma</DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="consumer" className="flex items-center gap-2">
              <User className="w-4 h-4" />
              Consumidor
            </TabsTrigger>
            <TabsTrigger value="producer" className="flex items-center gap-2">
              <Store className="w-4 h-4" />
              Productor
            </TabsTrigger>
          </TabsList>

          <TabsContent value="consumer" className="space-y-4">
            <form onSubmit={(e) => handleSubmit(e, "consumer")} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="consumer-email">Correo Electrónico</Label>
                <Input id="consumer-email" name="email" type="email" placeholder="tu@email.com" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="consumer-password">Contraseña</Label>
                <div className="relative">
                  <Input
                    id="consumer-password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              <Button type="submit" className="w-full bg-secondary hover:bg-secondary/90" disabled={isLoading}>
                {isLoading ? "Iniciando sesión..." : "Iniciar Sesión como Consumidor"}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="producer" className="space-y-4">
            <form onSubmit={(e) => handleSubmit(e, "producer")} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="producer-email">Correo Electrónico</Label>
                <Input id="producer-email" name="email" type="email" placeholder="productor@email.com" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="producer-password">Contraseña</Label>
                <div className="relative">
                  <Input
                    id="producer-password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              <Button type="submit" className="w-full bg-forest hover:bg-forest/90" disabled={isLoading}>
                {isLoading ? "Iniciando sesión..." : "Iniciar Sesión como Productor"}
              </Button>
            </form>
          </TabsContent>
        </Tabs>

        <div className="text-center text-sm text-muted-foreground">
          ¿No tienes cuenta?{" "}
          <Button variant="link" className="p-0 h-auto text-secondary">
            Regístrate aquí
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
