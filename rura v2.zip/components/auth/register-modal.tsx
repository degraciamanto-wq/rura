"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { User, Store, Eye, EyeOff, Phone } from "lucide-react"

interface RegisterModalProps {
  isOpen: boolean
  onClose: () => void
  onRegister: (userType: "consumer" | "producer", userData: any) => void
}

export function RegisterModal({ isOpen, onClose, onRegister }: RegisterModalProps) {
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("consumer")

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>, userType: "consumer" | "producer") => {
    e.preventDefault()
    setIsLoading(true)

    const formData = new FormData(e.currentTarget)
    const userData = {
      email: formData.get("email") as string,
      name: formData.get("name") as string,
      phone: formData.get("phone") as string,
      userType,
      id: Math.random().toString(36).substr(2, 9),
    }

    if (userType === "producer") {
      userData.farmName = formData.get("farmName") as string
      userData.location = formData.get("location") as string
      userData.description = formData.get("description") as string
      userData.whatsapp = formData.get("whatsapp") as string
    }

    // Simulate API call
    setTimeout(() => {
      onRegister(userType, userData)
      setIsLoading(false)
      onClose()
    }, 1000)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-heading text-xl text-forest">Registrarse en RURA</DialogTitle>
          <DialogDescription>Crea tu cuenta para comenzar a usar la plataforma</DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="consumer" className="flex items-center gap-2">
              <User className="w-4 h-4" />
              Consumidor
            </TabsTrigger>
            <TabsTrigger value="producer" className="flex items-center gap-2">
              <Store className="w-4 h-4" />
              Productor
            </TabsTrigger>
          </TabsList>

          <TabsContent value="consumer" className="space-y-4">
            <form onSubmit={(e) => handleSubmit(e, "consumer")} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="consumer-name">Nombre Completo</Label>
                <Input id="consumer-name" name="name" placeholder="Juan Pérez" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="consumer-email">Correo Electrónico</Label>
                <Input id="consumer-email" name="email" type="email" placeholder="tu@email.com" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="consumer-phone">Teléfono</Label>
                <Input id="consumer-phone" name="phone" type="tel" placeholder="+57 300 123 4567" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="consumer-password">Contraseña</Label>
                <div className="relative">
                  <Input
                    id="consumer-password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              <Button type="submit" className="w-full bg-secondary hover:bg-secondary/90" disabled={isLoading}>
                {isLoading ? "Registrando..." : "Registrarse como Consumidor"}
              </Button>
            </form>
          </TabsContent>

          <TabsContent value="producer" className="space-y-4">
            <form onSubmit={(e) => handleSubmit(e, "producer")} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="producer-name">Nombre del Responsable</Label>
                <Input id="producer-name" name="name" placeholder="María García" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="producer-farm">Nombre de la Finca/Empresa</Label>
                <Input id="producer-farm" name="farmName" placeholder="Finca Los Robles" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="producer-email">Correo Electrónico</Label>
                <Input id="producer-email" name="email" type="email" placeholder="productor@email.com" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="producer-phone">Teléfono</Label>
                <Input id="producer-phone" name="phone" type="tel" placeholder="+57 300 123 4567" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="producer-whatsapp">WhatsApp (para contacto directo)</Label>
                <div className="relative">
                  <Phone className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="producer-whatsapp"
                    name="whatsapp"
                    type="tel"
                    placeholder="+57 300 123 4567"
                    className="pl-8"
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="producer-location">Ubicación</Label>
                <Input id="producer-location" name="location" placeholder="Cundinamarca, Colombia" required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="producer-description">Descripción de tu producción</Label>
                <Textarea
                  id="producer-description"
                  name="description"
                  placeholder="Describe qué productos cultivas y tus métodos de producción..."
                  rows={3}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="producer-password">Contraseña</Label>
                <div className="relative">
                  <Input
                    id="producer-password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              <Button type="submit" className="w-full bg-forest hover:bg-forest/90" disabled={isLoading}>
                {isLoading ? "Registrando..." : "Registrarse como Productor"}
              </Button>
            </form>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
