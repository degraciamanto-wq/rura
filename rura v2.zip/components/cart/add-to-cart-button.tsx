"use client"

import { Button } from "@/components/ui/button"
import { ShoppingCart, Check } from "lucide-react"
import { useState } from "react"
import { useCart, type CartItem } from "@/hooks/use-cart"
import { useAuth } from "@/hooks/use-auth"
import { cn } from "@/lib/utils"

interface AddToCartButtonProps {
  product: Omit<CartItem, "quantity">
  quantity?: number
  className?: string
  variant?: "default" | "outline" | "ghost"
  size?: "sm" | "default" | "lg"
}

export function AddToCartButton({
  product,
  quantity = 1,
  className,
  variant = "default",
  size = "default",
}: AddToCartButtonProps) {
  const { addItem, setCartOpen } = useCart()
  const { user } = useAuth()
  const [isAdded, setIsAdded] = useState(false)

  // Only show cart functionality for consumers or non-authenticated users
  const showCart = !user || user.userType === "consumer"

  if (!showCart) {
    return null
  }

  const handleAddToCart = () => {
    addItem(product, quantity)
    setIsAdded(true)

    // Show cart sidebar after adding item
    setTimeout(() => {
      setCartOpen(true)
    }, 300)

    // Reset button state after animation
    setTimeout(() => {
      setIsAdded(false)
    }, 2000)
  }

  return (
    <Button
      onClick={handleAddToCart}
      variant={variant}
      size={size}
      className={cn("transition-all duration-200", isAdded && "bg-green-600 hover:bg-green-600", className)}
      disabled={isAdded}
    >
      {isAdded ? (
        <>
          <Check className="w-4 h-4 mr-2" />
          Agregado
        </>
      ) : (
        <>
          <ShoppingCart className="w-4 h-4 mr-2" />
          Agregar al Carrito
        </>
      )}
    </Button>
  )
}
