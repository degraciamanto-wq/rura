import { Card, CardContent } from "@/components/ui/card"
import { Wheat, Apple, Sprout } from "lucide-react"
import Link from "next/link"

const categories = [
  {
    name: "Semillas",
    icon: Sprout,
    description: "Semillas de alta calidad para tu cultivo",
    count: "120+ productos",
    href: "/categorias/semillas",
  },
  {
    name: "Granos",
    icon: Wheat,
    description: "Granos frescos y nutritivos",
    count: "85+ productos",
    href: "/categorias/granos",
  },
  {
    name: "Frutas",
    icon: Apple,
    description: "Frutas frescas de temporada",
    count: "200+ productos",
    href: "/categorias/frutas",
  },
]

export function Categories() {
  return (
    <section className="py-16 bg-muted/30">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-heading font-bold text-forest mb-4">Nuestras Categorías</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explora nuestra amplia selección de productos agrícolas organizados por categorías
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {categories.map((category) => (
            <Link key={category.name} href={category.href}>
              <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-secondary">
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 mx-auto mb-4 bg-secondary/10 rounded-full flex items-center justify-center">
                    <category.icon className="w-8 h-8 text-secondary" />
                  </div>
                  <h3 className="text-xl font-heading font-semibold mb-2 text-forest">{category.name}</h3>
                  <p className="text-muted-foreground mb-2">{category.description}</p>
                  <p className="text-sm text-secondary font-medium">{category.count}</p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
