"use client"

import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Star, MapPin, MessageCircle } from "lucide-react"
import Image from "next/image"
import { AddToCartButton } from "@/components/cart/add-to-cart-button"

const featuredProducts = [
  {
    id: 1,
    name: "Semillas de Tomate Cherry",
    producer: "Finca Los Robles",
    location: "Cundinamarca",
    price: 15000,
    rating: 4.8,
    reviews: 24,
    image: "/semillas-tomate-cherry.jpg",
    category: "Semillas",
    whatsapp: "+573001234567",
  },
  {
    id: 2,
    name: "Quinoa Orgánica",
    producer: "Granja Verde",
    location: "Boyacá",
    price: 25000,
    rating: 4.9,
    reviews: 18,
    image: "/quinoa-organica.jpg",
    category: "Granos",
    whatsapp: "+573007654321",
  },
  {
    id: 3,
    name: "Manzanas Rojas",
    producer: "Huerta San José",
    location: "Antioquia",
    price: 8000,
    rating: 4.7,
    reviews: 32,
    image: "/manzanas-rojas-frescas.jpg",
    category: "Frutas",
    whatsapp: "+573009876543",
  },
]

export function FeaturedProducts() {
  const handleWhatsAppContact = (phone: string, productName: string) => {
    const message = encodeURIComponent(`Hola, estoy interesado en ${productName}`)
    window.open(`https://wa.me/${phone.replace("+", "")}?text=${message}`, "_blank")
  }

  return (
    <section className="py-16">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-heading font-bold text-forest mb-4">Productos Destacados</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Los productos más populares y mejor valorados por nuestra comunidad
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredProducts.map((product) => (
            <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                <Image
                  src={product.image || "/placeholder.svg"}
                  alt={product.name}
                  width={300}
                  height={200}
                  className="w-full h-48 object-cover"
                />
                <Badge className="absolute top-2 left-2 bg-secondary text-secondary-foreground">
                  {product.category}
                </Badge>
              </div>
              <CardContent className="p-4">
                <h3 className="font-heading font-semibold text-lg mb-2 text-forest">{product.name}</h3>
                <div className="flex items-center text-sm text-muted-foreground mb-2">
                  <MapPin className="w-4 h-4 mr-1" />
                  {product.producer} - {product.location}
                </div>
                <div className="flex items-center mb-3">
                  <div className="flex items-center">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400 mr-1" />
                    <span className="text-sm font-medium">{product.rating}</span>
                    <span className="text-sm text-muted-foreground ml-1">({product.reviews} reseñas)</span>
                  </div>
                </div>
                <div className="text-2xl font-bold text-secondary mb-4">${product.price.toLocaleString()} COP</div>
              </CardContent>
              <CardFooter className="p-4 pt-0 flex gap-2">
                <AddToCartButton
                  product={{
                    id: product.id,
                    name: product.name,
                    price: product.price,
                    image: product.image,
                    producer: product.producer,
                    category: product.category,
                  }}
                  className="flex-1"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleWhatsAppContact(product.whatsapp, product.name)}
                  className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground"
                >
                  <MessageCircle className="w-4 h-4" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
