import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Facebook, Instagram, Twitter, Phone, Mail, MapPin } from "lucide-react"
import Image from "next/image"

export function Footer() {
  return (
    <footer className="border-t bg-forest text-forest-foreground">
      <div className="container py-10">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-4">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Image src="/logo.png" alt="RURA" width={32} height={32} />
              <span className="font-heading text-xl font-bold">RURA</span>
            </div>
            <p className="text-sm text-forest-foreground/80 mb-4">
              Conectando productores y consumidores para un futuro agrícola sostenible.
            </p>
            <div className="flex space-x-2">
              <Button variant="ghost" size="icon" className="text-forest-foreground hover:bg-forest-foreground/10">
                <Facebook className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" className="text-forest-foreground hover:bg-forest-foreground/10">
                <Instagram className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" className="text-forest-foreground hover:bg-forest-foreground/10">
                <Twitter className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <div>
            <h3 className="text-lg font-heading font-semibold mb-4">Navegación</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/productos" className="text-sm text-forest-foreground/80 hover:text-forest-foreground">
                  Productos
                </Link>
              </li>
              <li>
                <Link href="/productores" className="text-sm text-forest-foreground/80 hover:text-forest-foreground">
                  Productores
                </Link>
              </li>
              <li>
                <Link href="/categorias" className="text-sm text-forest-foreground/80 hover:text-forest-foreground">
                  Categorías
                </Link>
              </li>
              <li>
                <Link href="/resenas" className="text-sm text-forest-foreground/80 hover:text-forest-foreground">
                  Reseñas
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-heading font-semibold mb-4">Soporte</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/ayuda" className="text-sm text-forest-foreground/80 hover:text-forest-foreground">
                  Centro de Ayuda
                </Link>
              </li>
              <li>
                <Link href="/como-comprar" className="text-sm text-forest-foreground/80 hover:text-forest-foreground">
                  Cómo Comprar
                </Link>
              </li>
              <li>
                <Link href="/como-vender" className="text-sm text-forest-foreground/80 hover:text-forest-foreground">
                  Cómo Vender
                </Link>
              </li>
              <li>
                <Link href="/terminos" className="text-sm text-forest-foreground/80 hover:text-forest-foreground">
                  Términos y Condiciones
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-heading font-semibold mb-4">Contacto</h3>
            <div className="space-y-3">
              <div className="flex items-center text-sm text-forest-foreground/80">
                <Phone className="h-4 w-4 mr-2" />
                +57 300 123 4567
              </div>
              <div className="flex items-center text-sm text-forest-foreground/80">
                <Mail className="h-4 w-4 mr-2" />
                info@rura.com
              </div>
              <div className="flex items-center text-sm text-forest-foreground/80">
                <MapPin className="h-4 w-4 mr-2" />
                Bogotá, Colombia
              </div>
            </div>
          </div>
        </div>
        <div className="mt-10 border-t border-forest-foreground/20 pt-8 text-center">
          <p className="text-sm text-forest-foreground/80">
            © {new Date().getFullYear()} RURA. Todos los derechos reservados.
          </p>
        </div>
      </div>
    </footer>
  )
}
