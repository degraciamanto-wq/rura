import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"

export function Hero() {
  return (
    <div className="relative">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20" />
      <div className="relative mx-auto max-w-5xl px-6 py-24 sm:py-32 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <div className="mb-8">
            <Image src="/logo.png" alt="RURA" width={120} height={120} className="mx-auto" />
          </div>
          <h1 className="text-4xl font-heading font-bold tracking-tight sm:text-6xl text-forest">
            Conectamos Productores y Consumidores
          </h1>
          <p className="mt-6 text-lg leading-8 text-muted-foreground font-body">
            Descubre productos agrícolas frescos directamente de los productores locales. Semillas, granos, frutas y
            más, con la calidad que buscas.
          </p>
          <div className="mt-10 flex items-center justify-center gap-x-6">
            <Link href="/productos">
              <Button size="lg" className="rounded-full bg-secondary hover:bg-secondary/90 text-secondary-foreground">
                Explorar Productos
              </Button>
            </Link>
            <Link href="/vender">
              <Button
                size="lg"
                variant="outline"
                className="rounded-full border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground bg-transparent"
              >
                Vender Productos
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
