"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Menu, Search, ShoppingCart, User, LogIn, LogOut } from "lucide-react"
import Link from "next/link"
import { useState } from "react"
import Image from "next/image"
import { useAuth } from "@/hooks/use-auth"
import { useCart } from "@/hooks/use-cart"
import { LoginModal } from "@/components/auth/login-modal"
import { RegisterModal } from "@/components/auth/register-modal"
import { CartSidebar } from "@/components/cart/cart-sidebar"
import { useRouter } from "next/navigation"

export function Navigation() {
  const { user, isAuthenticated, login, logout } = useAuth()
  const { getTotalItems, toggleCart } = useCart()
  const [showLoginModal, setShowLoginModal] = useState(false)
  const [showRegisterModal, setShowRegisterModal] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const router = useRouter()

  const handleLogin = (userType: "consumer" | "producer", userData: any) => {
    login(userType, userData)
  }

  const handleRegister = (userType: "consumer" | "producer", userData: any) => {
    login(userType, userData)
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      router.push(`/buscar?q=${encodeURIComponent(searchQuery.trim())}`)
    }
  }

  const cartItemsCount = getTotalItems()

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center">
          <div className="mr-4 hidden md:flex">
            <Link href="/" className="mr-6 flex items-center space-x-2">
              <Image src="/logo.png" alt="RURA" width={32} height={32} />
              <span className="hidden font-heading text-xl font-bold text-secondary sm:inline-block">RURA</span>
            </Link>
            <nav className="flex items-center space-x-6 text-sm font-medium">
              <Link href="/productos" className="transition-colors hover:text-secondary text-foreground">
                Productos
              </Link>
              <Link href="/productores" className="transition-colors hover:text-secondary text-foreground">
                Productores
              </Link>
              <Link href="/categorias" className="transition-colors hover:text-secondary text-foreground">
                Categorías
              </Link>
              <Link href="/resenas" className="transition-colors hover:text-secondary text-foreground">
                Reseñas
              </Link>
            </nav>
          </div>
          <Sheet>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                className="mr-2 px-0 text-base hover:bg-transparent focus-visible:bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 md:hidden"
              >
                <Menu className="h-6 w-6" />
                <span className="sr-only">Toggle Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="pr-0">
              <div className="flex items-center space-x-2 mb-6">
                <Image src="/logo.png" alt="RURA" width={24} height={24} />
                <span className="font-heading text-lg font-bold text-secondary">RURA</span>
              </div>
              <nav className="grid gap-6 px-2 py-6">
                <Link href="/productos" className="hover:text-secondary">
                  Productos
                </Link>
                <Link href="/productores" className="hover:text-secondary">
                  Productores
                </Link>
                <Link href="/categorias" className="hover:text-secondary">
                  Categorías
                </Link>
                <Link href="/resenas" className="hover:text-secondary">
                  Reseñas
                </Link>
              </nav>
            </SheetContent>
          </Sheet>
          <div className="flex flex-1 items-center justify-between space-x-2 md:justify-end">
            <div className="w-full flex-1 md:w-auto md:flex-none">
              <form onSubmit={handleSearch} className="relative">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar productos agrícolas..."
                  className="pl-8 md:w-[300px] lg:w-[400px]"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </form>
            </div>
            <div className="flex items-center space-x-2">
              {(!isAuthenticated || user?.userType === "consumer") && (
                <Button variant="ghost" size="sm" className="relative" onClick={toggleCart}>
                  <ShoppingCart className="h-5 w-5" />
                  {cartItemsCount > 0 && (
                    <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 text-xs bg-secondary text-secondary-foreground">
                      {cartItemsCount}
                    </Badge>
                  )}
                </Button>
              )}
              {isAuthenticated ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <User className="mr-2 h-4 w-4" />
                      {user?.name}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem asChild>
                      <Link href="/perfil">Mi Perfil</Link>
                    </DropdownMenuItem>
                    {user?.userType === "producer" && (
                      <DropdownMenuItem asChild>
                        <Link href="/mis-productos">Mis Productos</Link>
                      </DropdownMenuItem>
                    )}
                    {user?.userType === "consumer" && (
                      <DropdownMenuItem asChild>
                        <Link href="/mis-pedidos">Mis Pedidos</Link>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem onClick={logout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      Cerrar Sesión
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <div className="flex space-x-2">
                  <Button variant="outline" size="sm" onClick={() => setShowLoginModal(true)}>
                    <LogIn className="mr-2 h-4 w-4" />
                    Iniciar Sesión
                  </Button>
                  <Button
                    size="sm"
                    className="bg-secondary hover:bg-secondary/90"
                    onClick={() => setShowRegisterModal(true)}
                  >
                    Registrarse
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <LoginModal isOpen={showLoginModal} onClose={() => setShowLoginModal(false)} onLogin={handleLogin} />

      <RegisterModal
        isOpen={showRegisterModal}
        onClose={() => setShowRegisterModal(false)}
        onRegister={handleRegister}
      />

      <CartSidebar />
    </>
  )
}
