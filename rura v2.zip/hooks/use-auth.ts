"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

interface User {
  id: string
  email: string
  name: string
  userType: "consumer" | "producer"
  phone?: string
  farmName?: string
  location?: string
  description?: string
  whatsapp?: string
}

interface AuthState {
  user: User | null
  isAuthenticated: boolean
  login: (userType: "consumer" | "producer", userData: any) => void
  logout: () => void
  updateProfile: (userData: Partial<User>) => void
}

export const useAuth = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      isAuthenticated: false,
      login: (userType, userData) => {
        set({
          user: { ...userData, userType },
          isAuthenticated: true,
        })
      },
      logout: () => {
        set({
          user: null,
          isAuthenticated: false,
        })
      },
      updateProfile: (userData) => {
        set((state) => ({
          user: state.user ? { ...state.user, ...userData } : null,
        }))
      },
    }),
    {
      name: "rura-auth-storage",
    },
  ),
)
